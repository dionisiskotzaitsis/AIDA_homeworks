import numpy as np
import math

def chunks(l, n):
    return [l[i:i+n] for i in range(0, len(l), n)]

def KL(a, b):

    a = np.asarray(a, dtype=np.float)
    b = np.asarray(b, dtype=np.float)
    return np.sum(np.where(a != 0, a * np.log(a / b), 0))


def createArray(distributions):
    klArray = []
    for i in range(len(distributions)):
        counter = 0
        while counter<(len(distributions)):
            if counter==i:
                klArray.append(math.inf)
                counter=counter+1
            else:
                klArray.append(KL(distributions[i],distributions[counter]))
                counter=counter+1
    klArray=chunks(klArray,len(distributions))
    return klArray

def findMin(klArray):
    for rows in range(len(klArray)):
        minim = klArray[rows][0]
        colIn=0
        for columns in range(len(klArray[rows])):
            if klArray[rows][columns]<minim:
                minim=klArray[rows][columns]
                colIn=columns
        print(minim,rows,'->',colIn)


if __name__ == '__main__':
    distributions=[]
    inp=input("Give me the file\n")
    file=open(inp+'.txt','r+')
    for i in file:
        i=i.strip()
        i=i.split(',')
        distributions.append(i)
    print(distributions)
    klArray=createArray(distributions)
    print(klArray)
    findMin(klArray)


