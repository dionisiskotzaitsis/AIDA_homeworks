import numpy as np
from scipy.stats.contingency import margins
from sklearn.feature_selection import mutual_info_classif
from sklearn.metrics import mutual_info_score


def entropy(a):
    return -np.sum(np.where(a != 0, a * np.log(a), 0))


def KL(a, b):

    a = np.asarray(a, dtype=np.float)
    b = np.asarray(b, dtype=np.float)
    return np.sum(np.where(a != 0, a * np.log(a / b.T), 0))

if __name__ == '__main__':
    joint=[]
    inp = input("Give me the file\n")
    file = open(inp + '.txt', 'r+')
    for i in file:
        i=i.strip()
        i=i.split(',')
        joint.append(i)

    joint=np.array(joint).astype(np.float)

    x,y=margins(joint)

    h_x=entropy(x)
    kl=KL(x,y)

    mutual_info=h_x-kl
    print(mutual_info)