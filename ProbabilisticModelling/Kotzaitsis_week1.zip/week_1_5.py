import re
import sys
import matplotlib.pyplot as plt
import pandas as pd


class Graph():


    def __init__(self, vertices):
        self.V = vertices
        self.graph = [[0 for column in range(vertices)] for row in range(vertices)]

    def printSolution(self, dist):
        print("Vertex tDistance from Source")
        for node in range(self.V):
            print(node, "t", dist[node])

    def minDistance(self, dist, sptSet):
        min = sys.maxsize
        min_index=0
        for v in range(self.V):
            if dist[v] < min and sptSet[v] == False:
                min = dist[v]
                min_index = v
        return min_index

    def dijkstra(self, src):

        dist = [sys.maxsize] * self.V
        dist[src] = 0
        sptSet = [False] * self.V

        for cout in range(self.V):
            u = self.minDistance(dist, sptSet)
            sptSet[u] = True
            for v in range(self.V):
                if self.graph[u][v] > 0 and sptSet[v] == False and dist[v] > dist[u] + self.graph[u][v]:
                    dist[v] = dist[u] + self.graph[u][v]

        #self.printSolution(dist)
        return dist

############################################################################################################################################

def makeList():
    adjList = []
    with open('WikiAdjSmall.txt') as file:
        while (line := file.readline().rstrip()):
            line = re.findall(r'\d+', line)
            for i in range(len(line)):
                line[i] = int(line[i])
            adjList.append(line)
    return adjList


def make_adj_matrix(data, directed=False):
    summary = {}
    result = []
    nodes = []

    for start, end, weight in data:
        # store nodes names for further use
        if start not in nodes:
            nodes.append(start)
        if end not in nodes:
            nodes.append(end)

        print(sorted(nodes))
        summary.setdefault(start, {}).setdefault(end, 0)
        summary[start][end] += weight
        if not directed:
            summary.setdefault(end, {}).setdefault(start, 0)
            summary[end][start] += weight


    for i in nodes:
        row = []
        for j in nodes:
            row.append(summary.get(i, {}).get(j, 0))
        result.append(row)

    return result



def convert_to_matrix(graph):
    matrix = []
    for i in range(len(graph)):
        matrix.append([0]*len(graph))
        for j in graph[i]:
            matrix[i][j] = 1
    return matrix



def init(self, vertices):
    self.V = vertices
    self.graph = [[0 for column in range(vertices)]
                  for row in range(vertices)]

def printSolution(self, dist):
    print("Vertex tDistance from Source")
    for node in range(self.V):
        print(node, "t", dist[node])


def minDistance(self, dist, sptSet):
    min = sys.maxsize
    for v in range(self.V):
        if dist[v] < min and sptSet[v] == False:
            min = dist[v]
            min_index = v

    return min_index




def dijkstra(self, src):

    dist = [sys.maxsize] * self.V
    dist[src] = 0
    sptSet = [False] * self.V

    for cout in range(self.V):
        u = self.minDistance(dist, sptSet)
        sptSet[u] = True
        for v in range(self.V):
            if self.graph[u][v] > 0 and sptSet[v] == False and dist[v] > dist[u] + self.graph[u][v]:
                dist[v] = dist[u] + self.graph[u][v]

    self.printSolution(dist)





def main():
    adjList=makeList()
    shDist=[]
    matrix=(make_adj_matrix(adjList))
    print(matrix)
    g=Graph(len(matrix))
    g.graph=matrix
    for i in range(len(matrix)):
        shDist.append(g.dijkstra(i))
    print(shDist)

    histT=[]


    for i in range(21):
        histT.insert(i,0)
    for row in shDist:
        for elem in row:
            if elem<=20:
                histT[elem]=histT[elem]+1

    print(histT)

    df=pd.Series(histT)
    plt.bar(list(range(21)), df.values, align='center')
    plt.xticks(range(len(histT)), df.index.values, size='small')
    plt.show()

main()