import pandas as pd
import numpy as np
import math
import random
import matplotlib.pyplot as plt


def observations(theta,N,sigma,input):
    x = []
    y = []
    for i in range(N):
        x.append(i)
        y.append(math.sin(float(theta) * i) + random.gauss(0, sigma ** 2))
    if input==theta:
        plt.plot(x, y)
        plt.show()
    return y




def a_posteriori(obs,theta,sigma):
    posterior=1
    posteriorL=[]
    for i in range(len(obs)):
        for j in range(len(obs[i])):
            print(i,j)
            posterior=posterior*((1/(math.sqrt(2*math.pi*(sigma**2)))) * math.exp((-1/(sigma**2)) * pow((obs[i][j] - math.sin(j * theta)),2)))
        posterior=0.2*posterior
        posteriorL.append(posterior)
    print(posteriorL)
    return posteriorL



def a_priori(list):
    a_posteriori=[0.2,0.2,0.2,0.2,0.2]
    df = pd.Series(a_posteriori)
    a_posteriori=pd.Series(list)
    plt.bar(range(len(list)), df.values, align='center')
    plt.xticks(range(len(list)), list)
    plt.show()
    return a_posteriori



if __name__ == '__main__':
    theta = float(input("Give me theta\n"))
    obs=[]
    a_post=[]
    list=[-0.5,-0.25,0,0.25,0.5]
    print(list.index(float(theta)))
    for i in range(len(list)):
        print(list[i])
        obs.append(observations(list[i],50,1,theta))
    a_priori(list)
    print(obs)
    for i in range(len(list)):
        a_post=a_posteriori(obs,list[i],1)
    df = pd.Series(a_post)
    plt.bar(range(len(pd.Series(list))), df.values, align='center')
    plt.xticks(range(len(list)), list)
    plt.show()