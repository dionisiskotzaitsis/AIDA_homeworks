import numpy as np
import math
import matplotlib.pyplot as plt
import pandas as pd
from pandas.plotting import table

x=np.arange(-1.0, 2.1, 0.1).tolist()
y=[]
for i in x:
    y.append(math.exp(-i)+i**2)
print(x)
print(y)
mPlot=plt.plot(x,y)
plt.savefig('function.png')



DAX=[15587.36,15462.72,15249.38,15146.87,15199.14]
s_p500=[4471.37,4438.26,4363.80,4350.65,4361.19]
dj=[35294.76,34912.56,34377.81,34378.34,34496.06]
date=['15/10/21','14/10/21','13/10/21','12/10/21','11/10/21']
ax = plt.subplot(111, frame_on=False) # no visible frame
ax.xaxis.set_visible(False)  # hide the x axis
ax.yaxis.set_visible(False)  # hide the y axis


stox_list = pd.DataFrame(np.column_stack([DAX, dj, s_p500]), columns=['DAX', 'DOWN JONES', 'S&P 500'],index=date).transpose()
tbl=table(ax,stox_list,loc='center')
plt.savefig('stocks.png')