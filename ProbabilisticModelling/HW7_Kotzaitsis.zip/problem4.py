import numpy as np
import math
import pandas as pd
import matplotlib.pyplot as plt
import random as rd
import copy
from numpy import random
import numpy.matlib
from numpy.linalg import inv,det


def BayesLinReg(y, sumPhi, sumyPhi, maxits,tol,plotprogress):
    logpDgG = []
    B = len(sumPhi)
    N = len(y)
    sumyy = np.sum(np.power(y,2))
    beta = 100
    alpha = 1


    for loop in range(maxits):
        invS=np.eye(B)*np.array(alpha)+np.array(sumPhi)*np.array(beta)
        S = inv(invS)
        m = np.dot(np.multiply(beta, S), sumyPhi)
        alpha = B / (np.trace(S) + np.dot(m.T, m))
        beta = np.divide(N,(sumyy - np.dot(np.dot(2, m.T), sumyPhi) + np.dot(np.dot(m.T, sumPhi), m) + np.trace(np.dot(S, sumPhi))))
        d = np.dot(sumyPhi,beta)
        logpDgG.append(np.dot(- beta, sumyy) + np.dot(np.dot(d.T, invS), d) - np.log(det(S)) + np.dot(B,np.log(alpha)) + np.dot(N, np.log(beta)) - np.dot(N, np.log(np.dot(2, np.pi))))
        if loop>0:
            if (logpDgG[loop] - logpDgG[loop - 1]).all() < tol:
                break
        if plotprogress:
            plt.plot(logpDgG)
            plt.show()
    marglik=logpDgG
    return m, S, alpha, beta, marglik

def rbf(x,centres,lambdas,w):
    B=len(centres)
    t1=numpy.matlib.repmat(x,1,B) - centres
    t2=np.divide(t1 ** 2,lambdas)
    phi=np.exp(- t2).T
    y=np.dot(w.T,phi)
    return y,phi

def solver():
    x=[]
    xtest=random.randn(1,30)
    for item in xtest[0]:
        print('item',item)
        x.append(float(item))
    N = len(x)
    #y=np.sin(np.dot(5, x)) + np.dot(0.1, np.random.randn(1, N))
    lambdavals = np.arange(0.2,0.5, 0.01)
    s = np.ceil(np.sqrt(len(lambdavals)))
    centres = np.arange(- 1.5, 1.5, 0.1).reshape(1,30)
    y=np.exp(np.divide(-0.5*(x-centres)**2,lambdavals**2))
    for model in range(len(lambdavals)):
        mty=[]
        marglik = []
        varty = []
        lambdas = np.dot(lambdavals[model], np.ones((len(centres),1)))
        B = len(centres[0])
        sumPhi = np.zeros(B)
        sumyPhi = np.zeros((B,1))
        for n in range(N):
            dum, phi = rbf(x[n], centres, lambdas, np.ones((B,1)))
            sumPhi = sumPhi + np.dot(phi, phi.T)
            sumyPhi = sumyPhi + y[0][n]*phi
        maxits = copy.copy(50)
        tol = copy.copy(0.001)
        plotprogress = copy.copy(0)
        m, S, alpha, beta, add = BayesLinReg(y, sumPhi, sumyPhi, maxits,tol,plotprogress)
        marglik.append(add)
        testx = np.arange(- 2, 2, 0.01).reshape(400,1)
        for ct in range(len(testx)):
            add2, phi = rbf(testx[ct], centres, lambdas, m)
            mty.append(float(add2))
            add3 = np.dot(np.dot(phi.T, S), phi) + 1 / beta
            varty.append(add3)
        plt.subplot(s, s, model+1)
        plt.plot(testx,np.array(mty).reshape(len(mty),1))
        conf = np.sqrt(varty)
        plt.plot(testx, mty - np.array(conf).reshape(len(conf),1))
        plt.plot(testx, mty + np.array(conf).reshape(len(conf),1))
        plt.plot(np.asarray(x).reshape(1,len(x)), y, '.')
        plt.axis([- 2, 2, - 2, 2])
    plt.show()

    plt.bar(lambdavals, marglik)
    val= max(marglik)
    ind=marglik.index(val)
    plt.show()

if __name__ == '__main__':
    solver()