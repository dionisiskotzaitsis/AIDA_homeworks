import numpy as np
import pandas as pd
from pgmpy.models import BayesianModel
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination as VE


def makeModel(nodes,edges,CPDS):
    model=BayesianModel()
    model.add_nodes_from(nodes)
    model.add_edges_from(edges)
    for i in CPDS:
        model.add_cpds(i)
    print(model)
    print(model.check_model())
    return model


def makeQueries(model,query,evid):
    infer=VE(model)
    print(infer.query([str(query)],evidence=evid))
    #print(infer.query(['b'],evidence={'a':1,'r':1}))



if __name__ == '__main__':
    nodes=['b','a','e','r']
    edges = [('b', 'a'), ('e', 'a'), ('e', 'r')]
    cpds=[]
    cpd_b = TabularCPD('b', 2, [[0.99], [0.01]])
    cpd_a = TabularCPD(
        'a', 2,
        [[0.9999, 0.01, 0.01, 0.0001],
         [0.0001, 0.99, 0.99, 0.9999]],
        evidence=['b', 'e'],
        evidence_card=[2, 2])
    cpd_e=TabularCPD('e',2,[[0.999999],[ 0.000001]])
    cpd_r = TabularCPD('r', 2,
                       [[1, 0],
                        [0, 1]],
                       evidence=['e'],
                       evidence_card=[2])

    cpds.append(cpd_b)
    cpds.append(cpd_a)
    cpds.append(cpd_e)
    cpds.append(cpd_r)

    evid={}
    quest=input('Give me your query.\n')
    giv=input('Give me your evidence and values separated by comma. If you want to end press 0\n')
    while giv[0]!='0':
        evid[giv[0]]=int(giv[2])
        giv = input()

    print(quest)
    model=makeModel(nodes,edges,cpds)
    makeQueries(model,quest,evid)

