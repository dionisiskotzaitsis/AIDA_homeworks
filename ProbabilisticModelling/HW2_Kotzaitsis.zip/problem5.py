import numpy as np

def adjAndListCreator(a1,a2):
    g1 = [[int(col) for col in row] for row in a1]
    g2 = [[int(col) for col in row] for row in a2]

    adjacency_list1 = {}
    adjacency_list2 = {}
    for v1 in range(len(g1)):
        adjacency_list1.update({v1: [v2 for v2 in range(len(g1[v1])) if g1[v1][v2] == 1]})
    for v1 in range(len(g2)):
        adjacency_list2.update({v1: [v2 for v2 in range(len(g2[v1])) if g2[v1][v2] == 1]})
    return g1,g2,adjacency_list1,adjacency_list2


def skeleton(g1,g2):

    for i in range(len(g1)):
        for j in range(len(g1[i])):
            if g1[i][j]==1:
                g1_edges=[(i,j)]

    for i in range(len(g2)):
        for j in range(len(g2[i])):
            if g2[i][j]==1:
                g2_edges=[(i,j)]


    same_skeleton = True

    for pair in g1_edges:
        if pair not in g2_edges and (pair[1], pair[0]) not in g2_edges:
            same_skeleton = False
    for pair in g2_edges:
        if pair not in g1_edges and (pair[1], pair[0]) not in g1_edges:
            same_skeleton = False

    return same_skeleton


def immoralities(l1,l2):
    immoralities_1=[]
    immoralities_2=[]
    flag=True
    for i in l1:
        for j in l1:
            for m in l1[i]:
                if m in l1[j] and i<j and j not in l1[i] and i not in l1[j]:
                    immoralities_1=[(i,j,m)]

    for i in l2:
        for j in l2:
            for m in l2[i]:
                if m in l2[j] and i<j and j not in l2[i] and i not in l2[j]:
                    immoralities_2=[(i,j,m)]

    if len(immoralities_1)!=len(immoralities_2):
        flag=False

    for i in immoralities_1:
        if i not in immoralities_2:
            return False

    for i in immoralities_2:
        if i not in immoralities_1:
            return False

    return immoralities_1,immoralities_2,flag


if __name__ == '__main__':
    #a1=np.asarray([[0,1,1],[0,0,1],[0,0,0]])
    #a2 =np.asarray([[1, 2, 3], [0, 1, 1], [1, 0, 0]])
    a1=np.asarray([[0,1,0,0,0],[0,0,1,1,0],[0,0,0,1,0],[0,0,0,0,0],[0,0,0,1,0]])
    a2=np.asarray([[0,0,0,0,0],[1,0,0,0,0],[0,1,0,1,0],[0,1,0,0,0],[0,0,0,1,0]])
    graph1,graph2,list1,list2=adjAndListCreator(a1,a2)
    skel=skeleton(graph1,graph2)
    im_1,im_2,flag=immoralities(list1,list2)
    if skel==True and flag==True:
        print("Graph 1 and Graph 2 are Markov equivalent")
    else:
        print("Graph 1 and Graph 2 are not Markov equivalent")