import numpy as np
import matplotlib.pyplot as plt
from scipy.special import logsumexp


def priors():
    theta=np.arange(0.1, 1, 0.1).tolist()
    ptheta1=[0,0,0.01,0.1,0.78,0.1,0.01,0,0]
    ptheta2=[0.04,0.16,0.16,0.14,0,0.04,0.16,0.16,0.14]
    return theta,ptheta1,ptheta2


def calc(theta,p,nH,nT):
    probability=0
    if nH>800 or nT>800:
        for i in range(len(theta)):
            pr=(theta[i] ** nH) *((1 - theta[i]) ** nT) * (p[i])
            pr=np.log(pr)
            probability+=pr


    else:
        for i in range(len(theta)):
            probability+=(theta[i]**nH)*((1-theta[i])**nT)*(p[i])

    return probability

def factor(p1,p2):
    print("p(D|Mfair)= ", pr1)
    print("p(D|Mfbiased)= ", pr2)
    result=p1/p2
    if result==np.nan:
        result=0.0000001
    print('factor= ',result)


if __name__ == '__main__':
    theta,p1,p2=priors()
    nH=int(input("Give me the numer of heads\n"))
    nT=int(input("Give me the numer of tails\n"))
    pr1=calc(theta,p1,nH,nT)
    pr2=calc(theta,p2,nH,nT)
    factor(pr1,pr2)

