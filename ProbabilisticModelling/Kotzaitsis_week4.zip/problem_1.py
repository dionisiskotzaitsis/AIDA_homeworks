import scipy.io
import pandas as pd
import numpy as np
from pgmpy.models import BayesianModel
from pgmpy.inference import VariableElimination as VE
from pgmpy.estimators import MaximumLikelihoodEstimator
from pgmpy.estimators import BayesianEstimator



def a_quest():
    mat = scipy.io.loadmat('printer.mat')
    ones = np.ones((len(mat['x']), len(mat['x'][0])))
    indexes = ['fuse', 'drum', 'toner', 'paper', 'roller', 'burning', 'quality', 'wrinkled', 'multiple pages',
               'paper jam']
    mat['x'] = mat['x'] - ones
    mat = pd.DataFrame(mat['x'])
    mat['index'] = indexes
    mat = mat.set_index('index').transpose()
    edges = [('fuse', 'burning'), ('fuse', 'wrinkled'), ('fuse', 'paper jam'), ('drum', 'quality'), ('toner', 'quality'),
             ('paper', 'quality'), ('paper', 'wrinkled'), ('paper', 'multiple pages'), ('roller', 'multiple pages'),
             ('roller', 'paper jam')]
    model = BayesianModel(edges)
    mle = MaximumLikelihoodEstimator(model, mat)
    a=model.fit(mat, estimator=MaximumLikelihoodEstimator)
    inference=VE(model)
    print(inference.query(variables=['fuse'],evidence={'burning':1,'paper jam':1,'drum':0,'toner':0,'paper':0,'roller':0,'quality':0,'wrinkled':0,'multiple pages':0}))
    #print(inference.query(variables=["fuel", "drum", "toner", "paper", "roller"],evidence={'burning':1,'paper jam':1,'drum':0,'toner':0,'paper':0,'roller':0,'quality':0,'wrinkled':0,'multiple pages':0}))



def b_quest():
    mat = scipy.io.loadmat('printer.mat')
    ones = np.ones((len(mat['x']), len(mat['x'][0])))
    indexes = ['fuse', 'drum', 'toner', 'paper', 'roller', 'burning', 'quality', 'wrinkled', 'multiple pages',
               'paper jam']
    mat['x'] = mat['x'] - ones
    mat = pd.DataFrame(mat['x'])
    mat['index'] = indexes
    mat = mat.set_index('index').transpose()
    edges = [('fuse', 'burning'), ('fuse', 'wrinkled'), ('fuse', 'paper jam'), ('drum', 'quality'),
             ('toner', 'quality'),
             ('paper', 'quality'), ('paper', 'wrinkled'), ('paper', 'multiple pages'), ('roller', 'multiple pages'),
             ('roller', 'paper jam')]
    model = BayesianModel(edges)
    est = BayesianEstimator(model, mat)
    model.fit(mat, estimator=BayesianEstimator, prior_type="dirichlet",pseudo_counts=0.5)
    inference = VE(model)
    print(inference.query(variables=['fuse'],evidence={'burning': 1, 'paper jam': 1, 'drum': 0, 'toner': 0, 'paper': 0, 'roller': 0,'quality': 0, 'wrinkled': 0, 'multiple pages': 0}))
    #print(pd.DataFrame(inference.query(variables=['fuse'],evidence={})))




if __name__ == '__main__':
    model=a_quest()
    model2=b_quest()
