import scipy.io
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math



def m_step(v,q_1,q_2):
    h=[1,2]
    theta_new=(v*(h[0]*q_1+h[1]*q_2))/((h[0]**2)*q_1+(h[1]**2)*q_2)
    print('theta= ',theta_new)
    return theta_new

def e_step(v,theta):
    q_2_new=(math.exp(-(v-2*theta)**2))/((math.exp(-(v-2*theta)**2))+(math.exp(-(v-theta)**2)))
    print('q_2= ',q_2_new)
    return q_2_new

def plots(v,thetals,q_2lis):
    thet=np.arange(1,3.1,0.001).tolist()
    ll=[]
    for i in thet:
        ll.append(math.log((1/(2*math.sqrt(math.pi)))*(math.exp(-((v-i)**2))+math.exp(-((v-2*i)**2)))))

    plt.plot(thet,ll)
    plt.show()
    plt.plot(thetals,q_2lis)
    plt.show()


if __name__ == '__main__':
    theta=float(input("Give me theta\n"))
    v=float(input("Give me v\n"))
    q_2=float(input("Give me q(h=2)\n"))
    steps=int(input("Give me your steps\n"))

    q_2lis=[]
    thetals=[]
    if q_2<=1:
        q_1=1-q_2

    for i in range(steps):
        q_2lis.append(q_2)
        thetals.append(theta)
        theta_new=m_step(v,q_1,q_2)
        q_2_new=e_step(v,theta)
        theta=theta_new
        q_2=q_2_new
        q_1=1-q_2
####### We do not create the two plots. We create a plot for the input that that our user gives#############
    plots(v,thetals,q_2lis)