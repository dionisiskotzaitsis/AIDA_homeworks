import scipy.io
import pandas as pd
import numpy as np
from pgmpy.models import BayesianNetwork
from pgmpy.estimators import ExpectationMaximization as EM


def a_quest():
    mat = scipy.io.loadmat('EMprinter.mat')
    indexes = ['F', 'D', 'T', 'P', 'R', 'B', 'Q', 'W', 'M',
               'PJ']
    mat=pd.DataFrame(mat['x']).transpose()
    mat.astype(float)
    mat.columns=indexes
    mat = mat.replace([2.0, 1.0,np.nan], [True, False,0])
    print(mat)

    edges = [('F', 'B'), ('F', 'W'), ('F', 'PJ'), ('D', 'Q'), ('T', 'Q'),
             ('P', 'Q'), ('P', 'W'), ('P', 'M'), ('R', 'M'),
             ('R', 'PJ')]
    model = BayesianNetwork(edges)
    estimator=EM(model,mat,complete_samples_only=False)
    (estimator.get_parameters())
    for cpd in estimator.get_parameters():
        print(cpd)


if __name__ == '__main__':
    a_quest()
