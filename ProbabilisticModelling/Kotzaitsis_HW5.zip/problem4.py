import scipy.io
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math
from sklearn.mixture import GaussianMixture
import scipy.stats as stats



if __name__ == '__main__':
    file=input("Give me the file name\n")
    file=open(file+'.txt','r+')
    output=open('output.txt','w+')
    observations=[]
    for i in file:
        observations.append(float(i))

    observations=np.asarray(observations).reshape(-1,1)
    print(len(observations))

    gmm=GaussianMixture(n_components=2,init_params='random')
    gmm.fit(observations)

    labels=gmm.predict(observations)
    print((labels))
    means=list(gmm.means_[0])
    means.append(list(gmm.means_[1]))
    variances=list((gmm.covariances_[0])[0])
    variances.append(list((gmm.covariances_[1])[0]))
    print(means)
    print(variances)
    output.write("{} {} {}\n".format("Distribution 1:", float(gmm.means_[0]),float(gmm.covariances_[0][0])))
    output.write("{} {} {}\n".format("Distribution 1:", float(gmm.means_[1]),float(gmm.covariances_[1][0])))
    for i in range(len(observations)):
        if labels[i]==0:
            output.write("{} {}\n".format(float(observations[i]), 1))
        else:
            output.write("{} {}\n".format(float(observations[i]), 2))

    mus=[float(gmm.means_[0]),float(gmm.means_[1])]
    sigmas=[float(gmm.covariances_[0][0]),float(gmm.covariances_[1][0])]
    x = np.linspace(0, 40, 100)
    pdf = np.zeros(shape=x.shape)
    for m, s in zip(mus, sigmas):
        pdf += stats.norm.pdf(x, m, s)
    plt.plot(x, pdf)
    plt.show()

    # Gaussian Mixture implements EM algorithm for a set of Gaussian distributions