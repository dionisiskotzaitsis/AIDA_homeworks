import numpy as np


def parser(file,rowcount,colcount):
    prosimo=[]
    prosimo.insert(0,1)
    rowsign=[]
    rowname=[]
    colnameA=[]
    colnameB=[]
    bounds2DVec=[]
    rangeVec=[]
    rhsIndex=[]
    rangeIndex=[]
    rhsVal=[]
    vector=file.readlines()
    for i in range(len(vector)):
        if vector[i][:4] == 'NAME':
            continue
        #############################   ROWS   #################################
        elif vector[i][:4] == 'ROWS':
            j=i+1
            while vector[j][:7]!='COLUMNS':
                if vector[j][1]=='N':
                    antikeimenikiname = vector[j][4:12].strip()
                elif vector[j][1] == 'G':
                    rowcount = rowcount + 1
                    rowname.insert(rowcount, vector[j][4:].strip())
                    rowsign.insert(rowcount, 1)
                elif vector[j][1] == 'L':
                    rowcount = rowcount + 1
                    rowname.insert(rowcount, vector[j][4:].strip())
                    rowsign.insert(rowcount, -1)
                else:
                    rowcount = rowcount + 1
                    rowname.insert(rowcount, vector[j][4:].strip())
                    rowsign.insert(rowcount, 0)
                j=j+1
            continue
        #############################   COLUMNS   #################################
        elif vector[i][:7] == 'COLUMNS':
            j=i+1
            z=j
            ########################### Initializing A table ##########################
            while vector[j][:3]!='RHS':
                colname = vector[j][4:12]
                if colname.strip() not in colnameA:
                    colnameA.append(colname.strip())
                    colcount = colcount + 1
                j=j+1

            table = tableCreation(rowcount, colcount)
            antikTable=tableAntikeimeniki(colcount)
            colcount=0
            ########################### Filling A table ###################################
            while vector[z][:3]!='RHS':
                colname = vector[z][4:12]
                if colname.strip() not in colnameB:
                    colnameB.append(colname.strip())
                    colcount = colcount + 1
                arow = vector[z][14:22].strip()
                brow = vector[z][39:47].strip()

                if (arow in rowname):
                    table=tableMod(table,int(rowname.index(arow)),colcount,float(vector[z][23:36].strip()),0)
                if brow in rowname:
                    table=tableMod(table, int(rowname.index(brow)), colcount,float(vector[z][49:61].strip()),0)
                if (arow == antikeimenikiname):
                    antikTable=tableMod(antikTable,1,colcount,float(vector[z][23:36].strip()),1)
                if (brow == antikeimenikiname):
                    antikTable=tableMod(antikTable,1,colcount,float(vector[z][49:61].strip()),1)
                z=z+1

            continue
        #############################   RHS   #################################
        elif vector[i][:3] == 'RHS':
            m=i+1
            while (vector[m][:6]!="ENDATA") and (vector[m][:6]!="RANGES") and (vector[m][:6]!="BOUNDS"):
                arow = vector[m][14:22].strip()
                brow = vector[m][39:47].strip()
                if arow in rowname:
                    rhsIndex.append(int(rowname.index(arow)))
                    rhsVal.append(float(vector[m][23:36].strip()))
                if brow in rowname:
                    rhsIndex.append(int(rowname.index(brow)))
                    rhsVal.append(float(vector[m][49:61].strip()))
                m=m+1
            continue
        ##############################   RANGES   ###################################
        elif vector[i][:6] == "RANGES":
            #d=i+1
            #counter=0
            #while (vector[d][:6]!="BOUNDS") and (vector[d][:6]!="ENDATA"):
            #    arow = vector[d][14:22].strip()
            #    brow = vector[d][39:47].strip()
            #    if arow in rowname:
            #        rangeIndex.append(int(rowname.index(arow)))
            #        rangeVec.insert(counter,[vector[d][4:12].strip(),])
            #        #rangeVec.append(float(vector[d][23:36].strip()))
            #    if brow in rowname:
            #        rangeIndex.append(int(rowname.index(brow)))
            #        rangeVec.append(float(vector[d][49:61].strip()))
            #    counter=counter+1
            #    d = d + 1
            continue
        #############################    BOUNDS    ####################################
        elif vector[i][:6] == 'BOUNDS':
            counter=0
            w=i+1
            while vector[w][:6]!="ENDATA" and vector[w][:8]!="OBJSENSE":
                colName=vector[w][14:22].strip()
                nameOfRest=vector[w][0:3].strip()
                if nameOfRest=='FR' or nameOfRest=='MI' or nameOfRest=='PL':
                    val='None'
                else:
                    val=float(vector[w][24:36].strip())
                bounds2DVec.insert(counter, [colName,nameOfRest,val])
                counter=counter+1
                w=w+1
            continue
        #################################################################

        elif vector[i][:6] == 'ENDATA':
            break
        elif vector[i][:8]=='OBJSENSE':
            if vector[i+1][:5].strip()=='MAX':
                prosimo[0]=1
            else:
                prosimo[0]=-1
        else:
            continue
    return vector,rowcount,colcount,rowsign,rowname,colnameA,antikeimenikiname,table,antikTable,rhsIndex,rhsVal,bounds2DVec,prosimo

def tableCreation(rowC,colC):
    array=np.arange(rowC*colC)
    array=np.reshape(array,(rowC,colC))
    array=np.zeros_like(array,dtype=np.float64)

    return array

def tableAntikeimeniki(colC):
    array=np.arange(colC)
    array=np.reshape(array,(1,colC))
    array=np.zeros_like(array,dtype=np.float64)
    return array

def rhsTable(rowC,rhsInd,rhsVal):
    array=np.arange(rowC).reshape(rowC,1)
    array=np.zeros_like(array,dtype=np.float64)
    for j,z in zip(rhsInd,rhsVal):
        array[j][0]=array[j][0]+z
    return array

def tableMod(table,rowIndex,colIndex,value,flag):
    if flag==0:
        table[rowIndex][colIndex-1]=table[rowIndex][colIndex-1]+value
    else:
        table[rowIndex - 1][colIndex - 1] = table[rowIndex - 1][colIndex - 1] + value

    return table

def k_ton(table,b,c,eqin,index,c_0):
    for j in reversed(range(len(table[index]))):
        if table[index][j]!=0:
            b[index]=b[index]/table[index][j]
            table[index,:]=np.true_divide(table[index,:],table[index][j])
            eqin[index] = -1
            #print('column of interest ',table[:,j])
            nonzeroind = np.nonzero(table[:,j])[0]
            for m in nonzeroind:
                if m!=index:
                    b[m]=b[m]-table[m][j]*b[index]
                    table[m,:]=table[m,:]-table[m][j]*table[index,:]
                else:
                    continue
            if float(c[:,j])!=0:
                c_0=c_0+c[:,j]*b[index]
                c=c-c[:,j]*np.transpose(table[index,:])
            table=np.delete(table,np.s_[j],axis=1)
            c=np.delete(c,np.s_[j],axis=1)

            break
    return table,b,c,eqin,c_0

def singleton(table,b,c,eqin,index,c_0):
    for j in reversed(range(len(table[index]))):
        if table[index][j]!=0:
            if b[index] / table[index, j] < 0:
                print("The problem is infeasible\n")
            else:
                row=np.reshape(table[:,j],(len(table[:,j]),1))
                b[:] = b[:] - row * (b[index] / table[index, j])
                if float(c[:, j]) != 0:
                    c_0 = c_0 - c[:, j] * (b[index] / table[index, j])
                table = np.delete(table, np.s_[index], axis=0)
                table=np.delete(table,np.s_[j],axis=1)
                b = np.delete(b, np.s_[index], axis=0)
                c = np.delete(c, np.s_[j], axis=1)
                eqin = np.delete(eqin, np.s_[index], axis=0)

                break
    return table,b,c,eqin,c_0

def k_ton_check(table,rhsT,antikTable,rowsign,k,c_0):
    counter=0
    for i in reversed(range(len(table))):
        counter+=1
        if np.count_nonzero(table[i])==k and rowsign[i]==0:
            if k==1:
                table, rhsT, antikTable,rowsign, c_0 = singleton(table, rhsT, antikTable, rowsign,i,c_0)
                flag=0
                break
            else:
                table, rhsT, antikTable, rowsign,c_0 = k_ton(table, rhsT, antikTable, rowsign, i, c_0)
                flag=0
                break
        if counter==len(table):
            flag=1
            break

    return table,rhsT,antikTable,rowsign,c_0,flag

if __name__ == '__main__':
    rowcount,colcount=0,0
    imp = input("Give me your file\n")
    f = open(imp + ".mps", "r")
    vector, rowcount, colcount, rowsign, rowname,colname,antikeimeniki,table,antikTable,rhsIndex,rhsVal,boundsVec,prosimo=parser(f,colcount,rowcount)
    rhsT=rhsTable(rowcount,rhsIndex,rhsVal)
    rowsign=np.array(rowsign).reshape(len(rowsign),1)
    print('Number of rows= ', len(table), len(rhsT))
    print('Number of cols= ', len(table[0]), len(antikTable[0]))
    print(table.shape)
    print('Number of non-zeros= ',np.count_nonzero(table))
    k=input("Give me your starting k\n").strip()
    k=int(k)
    c_0=0
    flag=0
    while k!=0:
        if flag==0:
            table, rhsT, antikTable, rowsign,c_0,flag = k_ton_check(table, rhsT, antikTable, rowsign, k, c_0)
        else:
            k=k-1
            flag=0

    print('Number of rows= ', len(table), len(rhsT),len(rowsign))
    print('Number of cols= ', len(table[0]), len(antikTable[0]))
    print('Number of non-zeros= ', np.count_nonzero(table))
    print('c_0= ',c_0)

