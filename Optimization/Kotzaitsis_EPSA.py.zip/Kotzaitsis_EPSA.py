import numpy as np
from numpy.linalg import inv
import copy


def parser(file,rowcount,colcount):
    prosimo=[]
    prosimo.insert(0,1)
    rowsign=[]
    rowname=[]
    colnameA=[]
    colnameB=[]
    bounds2DVec=[]
    rangeVec=[]
    rhsIndex=[]
    rangeIndex=[]
    rhsVal=[]
    vector=file.readlines()
    for i in range(len(vector)):
        if vector[i][:4] == 'NAME':
            continue
        #############################   ROWS   #################################
        elif vector[i][:4] == 'ROWS':
            j=i+1
            while vector[j][:7]!='COLUMNS':
                if vector[j][1]=='N':
                    antikeimenikiname = vector[j][4:12].strip()
                elif vector[j][1] == 'G':
                    rowcount = rowcount + 1
                    rowname.insert(rowcount, vector[j][4:].strip())
                    rowsign.insert(rowcount, 1)
                elif vector[j][1] == 'L':
                    rowcount = rowcount + 1
                    rowname.insert(rowcount, vector[j][4:].strip())
                    rowsign.insert(rowcount, -1)
                else:
                    rowcount = rowcount + 1
                    rowname.insert(rowcount, vector[j][4:].strip())
                    rowsign.insert(rowcount, 0)
                j=j+1
            continue
        #############################   COLUMNS   #################################
        elif vector[i][:7] == 'COLUMNS':
            j=i+1
            z=j
            ########################### Initializing A table ##########################
            while vector[j][:3]!='RHS':
                colname = vector[j][4:12]
                if colname.strip() not in colnameA:
                    colnameA.append(colname.strip())
                    colcount = colcount + 1
                j=j+1

            table = tableCreation(rowcount, colcount)
            antikTable=tableAntikeimeniki(colcount)
            colcount=0
            ########################### Filling A table ###################################
            while vector[z][:3]!='RHS':
                colname = vector[z][4:12]
                if colname.strip() not in colnameB:
                    colnameB.append(colname.strip())
                    colcount = colcount + 1
                arow = vector[z][14:22].strip()
                brow = vector[z][39:47].strip()

                if (arow in rowname):
                    table=tableMod(table,int(rowname.index(arow)),colcount,float(vector[z][23:36].strip()),0)
                if brow in rowname:
                    table=tableMod(table, int(rowname.index(brow)), colcount,float(vector[z][49:61].strip()),0)
                if (arow == antikeimenikiname):
                    antikTable=tableMod(antikTable,1,colcount,float(vector[z][23:36].strip()),1)
                if (brow == antikeimenikiname):
                    antikTable=tableMod(antikTable,1,colcount,float(vector[z][49:61].strip()),1)
                z=z+1

            continue
        #############################   RHS   #################################
        elif vector[i][:3] == 'RHS':
            m=i+1
            while (vector[m][:6]!="ENDATA") and (vector[m][:6]!="RANGES") and (vector[m][:6]!="BOUNDS"):
                arow = vector[m][14:22].strip()
                brow = vector[m][39:47].strip()
                if arow in rowname:
                    rhsIndex.append(int(rowname.index(arow)))
                    rhsVal.append(float(vector[m][23:36].strip()))
                if brow in rowname:
                    rhsIndex.append(int(rowname.index(brow)))
                    rhsVal.append(float(vector[m][49:61].strip()))
                m=m+1
            continue
        ##############################   RANGES   ###################################
        elif vector[i][:6] == "RANGES":
            #d=i+1
            #counter=0
            #while (vector[d][:6]!="BOUNDS") and (vector[d][:6]!="ENDATA"):
            #    arow = vector[d][14:22].strip()
            #    brow = vector[d][39:47].strip()
            #    if arow in rowname:
            #        rangeIndex.append(int(rowname.index(arow)))
            #        rangeVec.insert(counter,[vector[d][4:12].strip(),])
            #        #rangeVec.append(float(vector[d][23:36].strip()))
            #    if brow in rowname:
            #        rangeIndex.append(int(rowname.index(brow)))
            #        rangeVec.append(float(vector[d][49:61].strip()))
            #    counter=counter+1
            #    d = d + 1
            continue
        #############################    BOUNDS    ####################################
        elif vector[i][:6] == 'BOUNDS':
            counter=0
            w=i+1
            while vector[w][:6]!="ENDATA" and vector[w][:8]!="OBJSENSE":
                colName=vector[w][14:22].strip()
                nameOfRest=vector[w][0:3].strip()
                if nameOfRest=='FR' or nameOfRest=='MI' or nameOfRest=='PL':
                    val='None'
                else:
                    val=float(vector[w][24:36].strip())
                bounds2DVec.insert(counter, [colName,nameOfRest,val])
                counter=counter+1
                w=w+1
            continue
        #################################################################

        elif vector[i][:6] == 'ENDATA':
            break
        elif vector[i][:8]=='OBJSENSE':
            if vector[i+1][:5].strip()=='MAX':
                prosimo[0]=1
            else:
                prosimo[0]=-1
        else:
            continue
    return vector,rowcount,colcount,rowsign,rowname,colnameA,antikeimenikiname,table,antikTable,rhsIndex,rhsVal,bounds2DVec,prosimo

def tableCreation(rowC,colC):
    array=np.arange(rowC*colC)
    array=np.reshape(array,(rowC,colC))
    array=np.zeros_like(array,dtype=np.float64)

    return array

def tableAntikeimeniki(colC):
    array=np.arange(colC)
    array=np.reshape(array,(1,colC))
    array=np.zeros_like(array,dtype=np.float64)
    return array

def rhsTable(rowC,rhsInd,rhsVal):
    array=np.arange(rowC).reshape(rowC,1)
    array=np.zeros_like(array,dtype=np.float64)
    for j,z in zip(rhsInd,rhsVal):
        array[j][0]=array[j][0]+z
    return array

def tableMod(table,rowIndex,colIndex,value,flag):
    if flag==0:
        table[rowIndex][colIndex-1]=table[rowIndex][colIndex-1]+value
    else:
        table[rowIndex - 1][colIndex - 1] = table[rowIndex - 1][colIndex - 1] + value

    return table

def standard2dual(table,antikTable,rowsign,rhsT):
    counter=0
    A_N=table
    N=[]
    B=[]
    N.extend(range(len(table[0])))
    A_B=np.zeros((len(rowsign),len(rowsign)))
    for i in range(len(rowsign)):
        if rowsign[i]!=0:
            counter+=1
            if rowsign[i]>0:
                A_B[i,i]=-1
            else:
                A_B[i,i]=1
            rowsign[i] = 0

    A_Binv=np.asarray(inv(A_B))
    A_Ninv=np.asarray(inv(A_N))
    B.extend(range(len(table[0]),len(table[0])+counter))
    antikTable_B=np.zeros((1,counter))
    antikTable_N=antikTable
    antikTable=np.hstack((antikTable,antikTable_B))
    table=np.hstack((table,A_B))
    x_B=np.matmul(A_Binv,rhsT)
    x_N=np.matmul(A_Ninv,rhsT)


    return table,antikTable,rowsign,rhsT,A_B,A_Binv,A_N,B,N,x_B,x_N,antikTable_B,antikTable_N,counter

def findP_Q(sN,s_0,A_Binv,table,d_b):
    P=[]
    Q=[]

    for i in range(len(sN[0])):
        if sN[0,i]<0:
            P.append(i)
        else:
            Q.append(i)
    lamda=np.ones((1,len(P)))

    for j in P:
        s_0 =s_0+ (1 * sN[0, j])
        d_b =d_b+ (1 * np.matmul(A_Binv, table[:,j]))
        d_b=-d_b

    return P,Q,d_b,lamda,s_0

def step_zero(table,A_B,A_Binv,A_N,antikTable_B,antikTable_N,s_0,d_b):
    w=np.matmul(antikTable_B,A_Binv)
    sN=antikTable_N-np.matmul(w,A_N)

    P,Q,d_b,lamda,s_0=findP_Q(sN,s_0,A_Binv,table,d_b)

    return s_0,d_b,P,Q,lamda,sN,w

def checkDirection(x_B,d_b):
    a=[]
    b=[]
    for i in range(len(x_B)):
        if x_B[i]<0:
            b.append(float(x_B[i]/(-d_b[i])))
        else:
            b.append(0)

        if d_b[i]<0:
            a.append(float(x_B[i]/(-d_b[i])))
        else:
            a.append(0)

    maxb=max(b)
    mina=min(a)
    if maxb<=mina:
        print("The direction db crosses the feasible region, we continue.\n")
        flag=1
    else:
        print("The direction db does not cross the feasible region.\n")
        flag=0
    return flag

def step_one(s_0,d_b,P,Q,lamda,sN,w,x_B,B):
    endflag=0
    k=x_k=r=minimum=0
    min_list=[]
    if len(P)==0:
        print("The problem is optimal\n")
        endflag=1
    else:
        if all(i >= 0 for i in d_b):
            if s_0==0:
                print("The problem is optimal\n")
                endflag=1
        else:
            for i in range(len(d_b)):
                if d_b[i]>=0:
                    min_list.append(np.inf)
                else:
                    min_list.append(x_B[i,0]/(-d_b[i]))
            minimum = min_list[0]
            r = 0
            k = B[0]
            for i in range(1,len(min_list)):
                if min_list[i] < minimum:
                    minimum = min_list[i]
                    r = i
                    k = B[r]
                    x_k = x_B[r]
                elif min_list[i] == minimum:
                    k2 = B[i]
                    if k2 < k:
                        k = k2
                        minimum = min_list[i]
                        r = i
                        x_k = x_B[i]
            if minimum==np.inf:
                print("The problem is unbounded\n")
                endflag=1

    return endflag,k,minimum,s_0,x_k,r

def step_two(A_Binv,table,r,P,Q,sN):
    table_p=np.asarray(table[:,P])
    table_q=np.asarray(table[:,Q])
    HrP=np.matmul(A_Binv[r,:],table_p)
    HrQ=np.matmul(A_Binv[r,:],table_q)

    theta1=[]
    theta2=[]
    print('P',P)
    print('Q',Q)
    print('sn',sN)
    if len(HrP)!=0:
        for i in range(len(P)):
            if HrP[i]>0 and i in P:
                theta1.append(float(-sN[:,P[i]]/HrP[i]))
            else:
                theta1.append(np.inf)
    else:
        theta1.append(np.inf)

    if len(HrQ)!=0:
        for i in range(len(Q)):
            if HrQ[i]<0 and i in Q:
                theta2.append(float(-sN[:,Q[i]]/HrQ[i]))
            else:
                theta2.append(np.inf)
    else:
        theta2.append(np.inf)
    #print("HrQ= ",HrQ)

    min1=theta1[0]
    min2=theta2[0]
    t1=0
    t2=0

    for i in range(1,len(theta1)):
        if theta1[i]<min1:
            min1=theta1[i]
            t1=i
        elif theta1[i]==min1 and min1!=np.inf:
            ttrial=i
            if P[ttrial]<P[t1]:
                min1=theta1[i]
                t1=ttrial

    for i in range(1,len(theta2)):
        if theta2[i]<min2:
            min2 = theta2[i]
            t2=i
        elif theta2[i]==min2 and min2!=np.inf:
            ttrial=i
            if Q[ttrial]<Q[t2]:
                min2=theta2[i]
                t2=ttrial

    if min1<=min2:
        l=P[t1]
    else:
        l=Q[t2]

    return l,t1,t2,theta1,theta2,HrP,HrQ,min1,min2

def step_three(B,l,P,Q,antikTable,lamda,r,k,d_b,rhsT,table,min1,min2,t1,t2):
    B[r]=l
    P_2=copy.deepcopy(P)
    Q_2=copy.deepcopy(Q)
    if min1<=min2:
        P_2.remove(l)
        Q_2.append(k)
    else:
        Q_2[t2]=k
    s_0=0
    N=P_2+Q_2
    d_b2=0
    A_B=table[:,B]
    A_Binv=np.asarray(inv(A_B))
    A_N=table[:,N]
    x_B=np.matmul(A_Binv,rhsT)
    w=np.matmul(antikTable[:,B],A_Binv)
    sN=antikTable[:,N]-np.matmul(w,A_N)
    for i in P_2:
        s_0=s_0+1*sN[:,i]
        d_b2=d_b2+(1*np.matmul(A_Binv,table[:,i]))
        d_b2=-d_b2
    if l in P :
        d_b2[r]=d_b[r]+1
    P=copy.deepcopy(P_2)
    Q=copy.deepcopy(Q_2)
    d_b=copy.deepcopy(d_b2)

    return P,Q,d_b,l,lamda,w,sN,s_0,A_Binv,x_B,B,lamda

if __name__ == '__main__':
    rowcount, colcount = 0, 0
    imp = input("Give me your file\n")
    f = open(imp + ".mps", "r")
    vector, rowcount, colcount, rowsign, rowname, colname, antikeimeniki, table, antikTable, rhsIndex, rhsVal, boundsVec, prosimo = parser(
        f, colcount, rowcount)
    rhsT = rhsTable(rowcount, rhsIndex, rhsVal)
    rowsign = np.array(rowsign).reshape(len(rowsign), 1)

    table=np.asarray(table)
    antikTable=np.asarray(antikTable)
    rowsign=np.asarray(rowsign)
    rhsT=np.asarray(rhsT)

    s_0=0
    d_b=0
    endflag=0
    table,antikTable,rowsign,rhsT,A_B,A_Binv,A_N,B,N,x_B,x_N,antikTable_B,antikTable_N,counter=standard2dual(table,antikTable,rowsign,rhsT)

    s_0,d_b,P,Q,lamda,sN,w=step_zero(table,A_B,A_Binv,A_N,antikTable_B,antikTable_N,s_0,d_b)
    flag=checkDirection(x_B,d_b)
    print("s_0= ",float(s_0))
    if flag==1:
        while endflag!=1:
            endflag,k,minimum,s_0,x_k,r=step_one(s_0,d_b,P,Q,lamda,sN,w,x_B,B)
            if endflag!=1:
                l,t1,t2,theta1,theta2,HrP,HrQ,min1,min2=step_two(A_Binv,table,r,P,Q,sN)
                P,Q,d_b,l,lamda,w,sN,s_0,A_Binv,x_B,B,lamda=step_three(B,l,P,Q,antikTable,lamda,r,k,d_b,rhsT,table,min1,min2,t1,t2)
            print('s_0= ',float(s_0))


