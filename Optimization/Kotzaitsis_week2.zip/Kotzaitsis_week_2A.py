import numpy as np


def sparse2CSR(matrix):
    Anz=[]
    JA=[]
    IA=[]
    iaCounter=0
    flag=0
    for i in range(len(matrix)):
        if all(np.asarray(matrix[i])==0):
            IA.append(iaCounter + 1)
        for j in range(len(matrix[i])):
            if matrix[i][j]!=0:
                Anz.append(matrix[i][j])
                #**Having a 1 indexed code**
                JA.append(j+1)
                iaCounter=iaCounter+1
                #Debugging
                #print("Matrix "+str(matrix[i][j]))
                #print("Countr "+str(iaCounter))
                if flag==0:
                    # Debugging
                    #print("I write now")
                    IA.append(iaCounter)
                    flag=1
                else:
                    # Debugging
                    #print("I didnt write that")
                    flag=1
        flag=0
    IA.append(len(JA)+1)

    print("Anz:\t" + str(Anz))
    print("JA:\t" + str(JA))
    print("IA:\t" + str(IA))
    return Anz,JA,IA



if __name__ == '__main__':
    A=[[0,-4,0,0,0],[-2,0,1,0,0],[0,0,1,0,0],[0,1,0,0,-5],[0,0,0,-9,0]]
    B=[[0,0,0,0,0,0],[5,0,0,0,0,0],[0,-3,0,0,2,0],[0,0,5,0,0,-1],[0,0,0,2,0,0],[0,7,0,0,0,1]]
    C=[[1,0,0,9,0,0],[5,0,0,0,0,0],[0,-3,0,0,2,0],[0,0,0,0,0,0],[0,0,0,2,0,0],[0,7,0,0,0,1]]
    D=[[1,0,0,9,0,0],[5,0,0,0,0,0],[0,-3,0,0,2,0],[0,0,5,0,0,-1],[0,0,0,2,0,0],[0,0,0,0,0,0]]
    E = [[1, 0, 0, 9, 0, 0], [5, 0, 0, 0, 0, 0], [0, -3, 0, 0, 2, 0], [0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0],
         [0, 7, 0, 0, 0, 1]]


    AnzA,JAA,IAA=sparse2CSR(A)
    AnzB,JAB,IAB=sparse2CSR(B)
    AnzC,JAC,IAC=sparse2CSR(C)
    AnzD,JAD,IAD=sparse2CSR(D)
    AnzE,JAE,IAE=sparse2CSR(E)