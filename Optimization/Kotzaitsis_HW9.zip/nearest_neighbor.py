import tsplib95
import numpy as np

def algorithm(node_no,graph):
    min_distance = np.zeros((node_no,), dtype=float)
    path = [[0 for x in range(node_no)] for y in range(node_no)]

    for start_node in range(node_no):
        print("start node",start_node)
        unvisited = np.ones((node_no,), dtype=int)
        unvisited[start_node] = 0
        path[start_node][0] = start_node

        node = start_node
        i = 1
        while checking_nodes(unvisited)==True and i < node_no:
            closest_path = float(np.inf)
            closest_node = node_no

            for node2 in range(node_no):
                if unvisited[node2] == 1 and 0 < graph[node][node2] < closest_path:
                    closest_path = graph[node][node2]
                    closest_node = node2

            if closest_node >= node_no:
                min_distance[start_node] = float(np.inf)
                break

            node = closest_node
            unvisited[node] = 0
            min_distance[start_node] = min_distance[start_node] + closest_path
            # print(min_distance[start_node])
            path[start_node][i] = node
            i = i + 1

    if not np.isinf(min_distance[start_node]):
        last_visited = path[start_node][node_no - 1]
        if graph[last_visited][start_node] > 0:
            min_distance[start_node] = min_distance[start_node] + graph[last_visited][start_node]
        else:
            min_distance[start_node] = float(np.inf)


    shortest_path = path[0]
    shortest_min_distance = min_distance.item(0)
    for start_node in range(node_no):
        if min_distance[start_node] < shortest_min_distance:
            shortest_min_distance = min_distance.item(start_node)
            shortest_path = path[start_node]

    print("distance : " + str(shortest_min_distance))
    print("path : ",shortest_path)

    return shortest_min_distance, shortest_path


def checking_nodes(unvisited):
    for u in unvisited:
        if u == 1:
            return True
    return False




if __name__ == '__main__':
    inp=input("Give me your file\n")

    with open(inp) as f:
        problem = tsplib95.read(f)


    graph=[]
    graphline = []
    counter=0
    for i in list(problem.edge_weights):
        for j in i:
            if counter<int(problem.dimension)-1:
                graphline.append(j)
                counter=counter+1
            elif counter==int(problem.dimension)-1:
                graphline.append(j)
                graph.append(graphline)
                graphline=[]
                counter=0


    node_no=int(problem.dimension)
    shortest_min_distance, shortest_path=algorithm(node_no,graph)