import tsplib95
import numpy as np

if __name__ == '__main__':
    inp=input("Give me your file\n")

    with open(inp+'.tsp') as f:
        problem = tsplib95.read(f)



    outputF=open(inp+'out.txt','w+')
    writer = str("Name\t" + str(problem.name) + '\n')
    outputF.write(writer)
    writer=str("Number of Nodes\t"+ str(list(problem.get_nodes()))+ '\n')
    outputF.write(writer)
    writer=str("Edge weights\n"+str(problem.edge_weights)+"\n")
    outputF.write(writer)
    writer = str("Edge weights\t" + str((problem.edge_weight_format)) + '\n')
    outputF.write(writer)
    writer = str("More info\n")
    for i in range(len(list(problem.get_nodes()))):
        for j in range(i+1,len(list(problem.get_nodes()))):
            edge=i,j
            weight = problem.get_weight(*edge)
            writer=str((f'The driving distance from node {edge[0]} to node {edge[1]} is {weight}.\n'))
            outputF.write(writer)
