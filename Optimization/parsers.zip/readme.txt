This parser comes for individual instances of multidimensional
knapsack problems.

The problem to be solved is:
 Max  sum{j=1,...,n} p(j)x(j)
 st   sum{j=1,...,n} c(i,j)x(j) <= b(i)       i=1,...,m
                     x(j)=0 or 1

The inputs are mknap files with a single problem (Watch the spacing.(\s) means a space):
number of variables (n)(\s)number of constraints (m)(\s)optimal solution value (zero if unavailable)
(\s)the coefficients p(j); j=1,...,n == p table, separated by (\s)
(\s)for each constraint i (i=1,...,m): the coefficients r(i,j); j=1,...,n == c table, separated by (\s)
(\s)the constraint right-hand sides b(i); i=1,...,m == b table, separated by (\s)

The outputs are given to a output file:
    p table
    c table
    b table
    optimal solution (if available)