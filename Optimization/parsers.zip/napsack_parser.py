import numpy as np
import pandas as pd


def readfile(file):
    opener=open(file+'.txt','r+')
    fl=opener.read()
    fl=fl.split('\n')
    return fl

def getProblemVars(fl):
    fline=fl[0].split(' ')
    n=int(fline[0].strip())
    m=int(fline[1].strip())
    opt=str(float(fline[2].strip()))
    return n,m,opt

def getProblemArrays(fl,n,m):
    parser=[]
    p=[]
    c=[]
    b=[]
    for i in range(1,len(fl)):
        parser.append(fl[i])
    parser=''.join(parser).replace(',','')
    parser=parser.lstrip(' ')
    parser=parser.split(' ')
    for j in range(n):
        p.append(float(parser[j]))
    p=np.asarray(p)
    p=p.reshape(1,n)
    multiplier=n*m
    for x in range(n,(n+multiplier)):
        c.append(float(parser[x]))
    c = np.asarray(c)
    c=c.reshape(m, n)
    for f in range((n+multiplier),(n+multiplier+m)):
        b.append(float(parser[f]))
    b=np.asarray(b)
    b=b.reshape(m,1)

    return p,c,b


def printer(p,c,b,opt,out):
    np.savetxt(out, p, fmt='%.3f', header='p=')
    np.savetxt(out, c, fmt='%.3f', header='c=')
    np.savetxt(out, b, fmt='%.3f', header='b=')
    if float(opt)!=0:
        out.write('# Optimal Value=\n')
        out.write(opt)


if __name__ == '__main__':
    file=input("Give me your filename\n")
    fl=readfile(file)
    out=open(file+'out.txt','w+')
    n,m,opt=getProblemVars(fl)
    p,c,b=getProblemArrays(fl,n,m)
    printer(p,c,b,opt,out)
