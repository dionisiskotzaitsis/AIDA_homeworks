import numpy
import pandas as pd
import random


def revParser(dimRest, dimVars, lBound, uBound, lVarBound, uVarBound, lRhsBound, uRhsBound, optSol,outFile):
    writer=str(str(dimVars)+' '+str(dimRest)+' '+str(optSol)+'\n')
    outFile.write(writer)
    outFile.write(' ')
    for i in range(dimVars):
        if i != dimVars - 1:
            outFile.write(str(round(random.uniform(lVarBound, uVarBound), 2)) + ' ')
        else:
            outFile.write(str(round(random.uniform(lVarBound, uVarBound), 2)) + '\n')
    for i in range(dimRest):
        outFile.write(' ')
        for j in range(dimVars):
            if j!=dimVars-1:
                outFile.write(str(round(random.uniform(lBound, uBound),2))+' ')
            else:
                outFile.write(str(round(random.uniform(lBound, uBound),2)) + '\n')
    outFile.write(' ')
    for i in range(dimRest):
        if i != dimRest-1:
            outFile.write(str(round(random.uniform(lRhsBound, uRhsBound),2)) + ' ')
        else:
            outFile.write(str(round(random.uniform(lRhsBound, uRhsBound),2)))



if __name__ == '__main__':
    nuOfPrb=int(input("How many problems do you want to create?\n"))
    name = str(input("Give me a name for your problem\n"))
    if nuOfPrb>0:
        for i in range(nuOfPrb):
            outFile=open(name+str(i)+'.txt','w+')
            flag=int(input("If you want to use the same bounds for all constraints press 1, else 0\n"))
            if flag==0:
                dimRest=int(input("Give me the number of constraints\n"))
                dimVars=int(input("Give me the number of vars\n"))
                lBound=float(input("Give me the lower bound for constraint coefficients\n"))
                uBound=float(input("Give me the upper bound for constraint coefficients\n"))
                lVarBound=float(input("Give me the lower bound for variable coefficients\n"))
                uVarBound=float(input("Give me the upper bound for variable coefficients\n"))
                lRhsBound=float(input("Give me the lower bound for RHS coefficients\n"))
                uRhsBound = float(input("Give me the upper bound for RHS coefficients\n"))
                optSol=float(input("If available, give me the optimal solution. If not, press 0\n"))
                revParser(dimRest, dimVars, lBound, uBound, lVarBound, uVarBound, lRhsBound, uRhsBound, optSol,outFile)
            else:
                dimRest = int(input("Give me the number of constraints\n"))
                dimVars = int(input("Give me the number of vars\n"))
                lBound = float(input("Give me the lower bound\n"))
                uBound = float(input("Give me the upper bound\n"))
                optSol=float(input("If available, give me the optimal solution. If not, press 0\n"))
                lVarBound=lBound
                lRhsBound=lBound
                uVarBound=uBound
                uRhsBound=uBound
                revParser(dimRest, dimVars, lBound, uBound, lVarBound, uVarBound, lRhsBound, uRhsBound, optSol,outFile)
