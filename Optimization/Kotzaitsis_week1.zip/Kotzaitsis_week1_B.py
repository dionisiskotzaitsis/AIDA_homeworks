import numpy as np
import pandas as pd


def parserV1(file):
    A = []
    b = []
    c = []
    Eqin = []
    R=[]
    Bs=[]
    for i in range(len(file)):
        if file[i][0]=="A":
            j=i
            while file[j][0]!="b" and file[j]!="\n" and file[j]!="\t\n":
                Ain = []
                file[j] = file[j].split()
                for m in file[j]:
                    m = m.replace("A=[", '')
                    m = m.replace("]", '')
                    if m!='':
                        Ain.append(float(m))
                A.append(Ain)
                j=j+1
        elif file[i][0]=="b":
            j=i
            while file[j][0]!="c" and file[j]!="\n" and file[j]!="\t\n":
                file[j] = file[j].split()
                for m in file[j]:
                    m = m.replace("b=[", '')
                    m = m.replace("]", '')
                    if m!='':
                        b.append(m)
                j = j + 1
        elif file[i][0]=="c":
            j=i
            while file[j][0] != "E" and file[j] != "\n" and file[j]!="\t\n":
                file[j] = file[j].split()
                for m in file[j]:
                    m = m.replace("c=[", '')
                    m = m.replace("]", '')
                    if m!='':
                        c.append(float(m))
                j = j + 1
        elif file[i][0]=="E":
            j = i
            while file[j][0] != "M" and file[j] != "\n" and file[j]!="\t\n":
                file[j] = file[j].split()
                for m in file[j]:
                    m = m.replace("Eqin=[", '')
                    m = m.replace("]", '')
                    if m!='':
                        Eqin.append(m)
                j = j + 1
        elif file[i][0]=="M":
            j = i
            while file[j][0] != "B" and file[j] != "\n" and file[j]!="\t\n":
                file[j] = file[j].split()
                for m in file[j]:
                    m = m.replace("MinMax=", '')
                    MM=m
                j = j + 1
        elif file[i][0]=="R":
            j = i
            while file[j][0] != "B" and file[j] != "\n" and file[j]!="\t\n":
                file[j] = file[j].split()
                for m in file[j]:
                    m = m.replace("R=[", '')
                    m = m.replace("]", '')
                    if m!='':
                        R.append(m)
                j = j + 1
        elif file[i][0]=="B":
            j = i
            while j!=len(file):
                BsIn=[]
                file[j] = file[j].split()
                for m in file[j]:
                    m = m.replace("BS=[", '')
                    m = m.replace("]", '')
                    if m!='':
                        BsIn.append(m)
                Bs.append(BsIn)
                j = j + 1
        else:
            continue
    return A,b,c,Eqin,MM,R,Bs





def parserV2(file):
    A = []
    b = []
    c = []
    Eqin = []
    R = []
    Bs = []


    for i in range(len(file)):
        if file[i]=='# A=\n':
            i=i+1
            while file[i]!='# b=\n':
                file[i]=file[i].split()
                A.append(file[i])
                i=i+1

        elif file[i]=='# b=\n':
            i=i+1
            while file[i] != '# C=\n':
                b.append(file[i].strip())
                i = i + 1

        elif file[i]=='# C=\n':
            i=i+1
            while file[i] != '# Eqin=\n':
                c = file[i].split()
                i = i + 1

        elif file[i]=='# Eqin=\n':
            i=i+1
            while file[i] != '# MinMax=\n' and file[i] != '# R=\n' and file[i] != '# Bs=\n':
                Eqin.append(int(float(file[i].strip())))
                i = i + 1

        elif file[i] == '# MinMax=\n':
            i=i+1
            MM=file[i]

        elif file[i]=='# R=\n':
            i=i+1
            while  file[i] != '# Bs=\n':
                file[i] = file[i].split()
                R.append(file[i])
                i = i + 1

        elif file[i] == '# Bs=\n':
            i = i + 1
            while i!=len(file):
                file[i] = file[i].split()
                Bs.append(file[i])
                i = i + 1
    print(c)

    return  A,b,c,Eqin,MM,R,Bs








def mpsCreator(input,output,A,b,c,Eqin,MM,R,Bs):
    rowNameArr=[]
    colNameArr=[]
    rhsNameArr=[]
    output.write('NAME          ' + input.upper()+'\n')
    output.write('ROWS'+'\n')
    output.write(' N  OBJ'+'\n')
    for i in range(len(Eqin)):
        rowName='R'+str(i+1).zfill(7)
        rowNameArr.append(rowName)
        if int(Eqin[i])==0:
            output.write(' E  '+rowName+'\n')
        if int(Eqin[i])==-1:
            output.write(' L  '+rowName+'\n')
        if int(Eqin[i])==1:
            output.write(' G  '+rowName+'\n')
    output.write('COLUMNS\n')
    A=np.asarray(A)
    AT=np.transpose(A)
    for i in range(len(AT)):
        colName = 'X' + str(i+1).zfill(7)
        colNameArr.append(colName)
        if float(float(c[i]))!=0:
            output.write('    '+colName+'  '+'OBJ'+'       '+str(c[i])+'\n')
        for j in range(len(A)):
            if A[j][i] != 0:
                output.write('    '+colName+'  '+rowNameArr[j]+'  '+str(A[j][i])+'\n')

    output.write('RHS\n')
    for i in range(len(b)):
        rhsName='W'+str(i+1).zfill(7)
        rhsNameArr.append(rhsName)
        if float(float(b[i]))!=0:
            output.write('    ' + rhsName + '  ' +rowNameArr[i]+ '  ' + str(b[i]) + '\n')
#############  RANGES ###################
    #for i in range(len(R)):

    output.write('BOUNDS\n')
    for i in range(len(Bs)):
        indexing=''.join(c for c in Bs[i][0] if c.isdigit())
        if str(Bs[i][2])!='None':
            output.write(' '+Bs[i][1]+' BOUND001  '+colNameArr[int(indexing)-1]+'  '+str(Bs[i][2])+'\n')
        else:
            output.write(' ' + Bs[i][1] + ' BOUND001  ' + colNameArr[int(indexing) - 1] + '  '+str(0)+'\n')
        #print(Bs[i])

    if int(MM)==1:
        output.write('OBJSENSE\n')
        output.write(' MAX\n')
    else:
        output.write('OBJSENSE\n')
        output.write(' MIN\n')

    output.write('ENDATA\n')







def main():
    inp = input()
    file = open(inp+'.txt', 'r')
    out=open(inp+'out.mps','w+')
    a=file.readlines()
    if a[0][0]=='#':
        A,b,c,Eqin,MinMax,R,Bs=parserV2(a)
        mpsCreator(inp,out,A,b,c,Eqin,MinMax,R,Bs)

    elif a[0][0]=='A':
        A,b,c,Eqin,MinMax,R,Bs=parserV1(a)
        print(A)
        print(b,c,Eqin,MinMax)
        print(Bs)
        print(MinMax)
        mpsCreator(inp,out,A,b,c,Eqin,MinMax,R,Bs)
    else:
        parserV1(a)


main()