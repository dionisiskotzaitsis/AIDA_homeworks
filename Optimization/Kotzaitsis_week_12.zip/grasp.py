import numpy as np
import pandas as pd
import random
import copy

def cost(solution, weight, value):
    max_value = 0
    max_weight=0
    for j in range(len(solution)):
        if solution[j] == 1:
            max_value += value[j]
            max_weight+=weight[j]


    return max_value,max_weight

def search(solution,weight,value,id,capacity):
    temp=solution[:]
    for i in range(len(temp)):
        max_weight=0
        max_value=0
        max_v=0
        if temp[i]==0:
            temp[i]=1
            for j in range(len(temp)):
                if temp[j]==1:
                    max_value+=value[id[j]]
                    max_weight+=weight[id[j]]
            temp[i]=0
        elif temp[i]==1:
            temp[i]=0
            for j in range(len(temp)):
                if temp[j]==1:
                    max_value+=value[id[j]]
                    max_weight+=weight[id[j]]
            temp[i]=1

        for j in range(len(solution)):
            if solution[j]==1:
                max_value+=value[id[j]]
        if capacity-max_weight>=0 and max_value>max_v:
            solution=temp[:]

    return solution

def construction(id,value,weight,capacity):
    solution=[]
    item={}

    for i in range(len(id)):
        item[i]=np.divide(value[i],weight[i]),value[i],weight[i]
    item=sorted(item.values(),reverse=True)
    leftovers=capacity

    currency=0

    while len(item)>0:
        lcr=[]
        for i in range(2):
            if i<len(item):
                lcr.append(item[i])

        s=random.choice(lcr)
        if s[2]<=leftovers:
            solution.append(s[1])
            leftovers-=s[2]
            currency+=s[2]

        item.pop(item.index(s))

    sol=[0 for i in range(len(value))]

    for j in value:
        if j in solution:
            sol[value.index(j)]=1

    return sol,currency

def grasp(max_iterations, id, value, weight, capacity):
    best = 0
    weightOfBag=0
    sol=[]
    for k in range(max_iterations):
        id_copy = []
        for i in range(len(id)):
            id_copy.append(id[i])
        solution, currency = construction(id_copy, value, weight, capacity)

        solution = search(solution, weight, value, id, capacity)
        solution2,wob = cost(solution, weight, value)
        if solution2 > best:
            best = solution2
            weightOfBag=wob
            sol=solution.copy()
    return best,weightOfBag,sol



if __name__ == '__main__':
    inp=input("Give me your file\n")
    f=open(inp)
    Lines = f.readlines()
    counter=0
    value=[]
    weight=[]
    id=[]
    for i in (Lines):
        i=i.strip()
        i=i.split()
        if counter==0:
            number=int(i[0])
            knapsack_threshold=int(i[1])
        else:
            id.append(counter-1)
            value.append(int(i[0]))
            weight.append(int(i[1]))
        counter=counter+1
    item_number=np.arange(1,int(number)+1)
    max_iterations=int(input("Give me max iterations of the algorithm\n"))
    solution,wOB,sol=grasp(max_iterations,id,value,weight,knapsack_threshold)
    print("Solution Bits=", sol)
    print("Value of Bag=",solution)
    print("Weight Of Bag=",wOB)
