import numpy as np
import pandas as pd
import random as rd
from random import randint

def cal_fitness(weight, value, population, threshold):

    # Καλουμε το fitness function το οποίο είναι πρακτικα το αθροισμα των όρων των value που έχει κάθε επιλογή
    # ως προς το profit(value) που θα έχουμε. Σε περίπτωση που τα βάρη περνάνε το όριο του "σακου" τότε το fit.val=0
    fitness = np.empty(population.shape[0])
    for i in range(population.shape[0]):
        S1 = np.sum(population[i] * value)
        S2 = np.sum(population[i] * weight)
        if S2 <= threshold:
            fitness[i] = S1
        else :
            fitness[i] = 0
    return fitness.astype(int)


def selection(fitness, num_parents, population):
    fitness = list(fitness)
    parents = np.empty((num_parents, population.shape[1]))
    for i in range(num_parents):
        max_fitness_idx = np.where(fitness == np.max(fitness))
        parents[i,:] = population[max_fitness_idx[0][0], :]
        fitness[max_fitness_idx[0][0]] = -999999
    return parents


def crossover(parents, num_offsprings):
    # crossover σε ενα σημείο με υψηλό crossover rate, για να γίνεται σχεδόν σε όλους η διαδικασία.
    offsprings = np.empty((num_offsprings, parents.shape[1]))
    crossover_point = int(parents.shape[1]/2)
    crossover_rate = 0.8
    i=0
    while (parents.shape[0] < num_offsprings):
        parent1_index = i%parents.shape[0] #παιρνει τον ι individual
        parent2_index = (i+1)%parents.shape[0] #και τον διπλα
        x = rd.random()
        if x > crossover_rate:
            continue
        parent1_index = i%parents.shape[0]
        parent2_index = (i+1)%parents.shape[0]
        offsprings[i,0:crossover_point] = parents[parent1_index,0:crossover_point]
        offsprings[i,crossover_point:] = parents[parent2_index,crossover_point:]
        i=+1
    return offsprings



def mutation(offsprings):
    #Μικρή μετάλλαξη με ποσοστό 5%
    mutants = np.empty((offsprings.shape))
    mutation_rate = 0.05
    for i in range(mutants.shape[0]):
        random_value = rd.random()
        mutants[i,:] = offsprings[i,:]
        if random_value > mutation_rate:
            continue
        int_random_value = randint(0,offsprings.shape[1]-1)
        if mutants[i,int_random_value] == 0:
            mutants[i,int_random_value] = 1
        else :
            mutants[i,int_random_value] = 0
    return mutants


def optimize(weight, value, population, pop_size, num_generations, threshold):
    parameters, fitness_history = [], []
    num_parents = int(pop_size[0] / 2)
    num_offsprings = pop_size[0] - num_parents
    for i in range(num_generations):
        fitness = cal_fitness(weight, value, population, threshold)
        fitness_history.append(fitness)
        parents = selection(fitness, num_parents, population)
        offsprings = crossover(parents, num_offsprings)
        mutants = mutation(offsprings)
        population[0:parents.shape[0], :] = parents
        population[parents.shape[0]:, :] = mutants

    print('Last generation: \n{}\n'.format(population))
    fitness_last_gen = cal_fitness(weight, value, population, threshold)
    print('Fitness of the last generation: \n{}\n'.format(fitness_last_gen))
    max_fitness = np.where(fitness_last_gen == np.max(fitness_last_gen))
    parameters.append(population[max_fitness[0][0], :])
    return parameters, fitness_history

if __name__ == '__main__':
    inp=input("Give me your file\n")
    f=open(inp)
    Lines = f.readlines()
    counter=0
    value=[]
    weight=[]
    for i in (Lines):
        i=i.strip()
        i=i.split()
        if counter==0:
            print("i1",i[1])
            number=int(i[0])
            knapsack_threshold=int(i[1])
        else:
            value.append(int(i[0]))
            weight.append(int(i[1]))
        counter=counter+1
    value=np.asarray(value)
    weight=np.asarray(weight)
    item_number=np.arange(1,int(number)+1)
    print('Item No.   Weight   Value')
    for i in range(item_number.shape[0]):
        print('{0}          {1}         {2}\n'.format(item_number[i], weight[i], value[i]))

    solutions_per_pop = 20
    pop_size = (solutions_per_pop, item_number.shape[0])
    initial_population = np.random.randint(2, size=pop_size)
    initial_population = initial_population.astype(int)
    num_generations = 50

    parameters, fitness_history = optimize(weight, value, initial_population, pop_size, num_generations,knapsack_threshold)
    print('The optimized solution is: \n{}'.format(np.array(parameters).tolist()))


    #You may need to re-run the code!!!!
    #Watch the sample knapsack files for the format
    #n: number of items
    #wmax: knapsack capacity
    #Example
    #n  wmax
    #v1 w1
    #v2 w2
    #vi wi
    #vn wn
    #vi: profit of item i
    #wi: weight of item i