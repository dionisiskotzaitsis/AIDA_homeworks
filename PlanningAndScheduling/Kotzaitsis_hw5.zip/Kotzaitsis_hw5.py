import time
from random import choice
from random import random
from copy import deepcopy
import numpy as np
import subprocess as sp

ACTIONS = [
    (-2, -2), (-1, -2), (0, -2), (1, -2), (2, -2),
    (-2, -1), (-1, -1), (0, -1), (1, -1), (2, -1),
    (-2, 0), (-1, 0), (0, 0), (1, 0), (2, 0),
    (-2, 1), (-1, 1), (0, 1), (1, 1), (2, 1),
    (-2, 2), (-1, 2), (0, 2), (1, 2), (2, 2)
]


def racetrack(racetrack):
    with open(racetrack+'.txt','r') as file:
        data=file.readlines()

    file.close()
    env=[]
    for i,line in enumerate(data):
        env.append([x for x in line])

    return env

def new_position(environment, x_crash, y_crash, velocity_x=0, velocity_y=0, acceptable_cells=('r', '1', '2')):

    rows = len(environment)
    columns = len(environment[0])
    max_radius = max(rows, columns)

    for radius in range(max_radius):

        if velocity_x == 0:
            x_off_range = range(-radius, radius + 1)
        elif velocity_x < 0:
            x_off_range = range(0, radius + 1)
        else:
            x_off_range = range(-radius, 1)

        for x_offset in x_off_range:

            x = x_crash + x_offset
            y_radius = radius - abs(x_offset)
            if velocity_y == 0:
                y_range = range(y_crash - y_radius, y_crash + y_radius + 1)
            elif velocity_y < 0:
                y_range = range(y_crash, y_crash + y_radius + 1)
            else:
                y_range = range(y_crash - y_radius, y_crash + 1)

            for y in y_range:

                if x < 0 or x >= rows:
                    continue
                if y < 0 or y >= columns:
                    continue
                if environment[x][y] in acceptable_cells:
                    return x, y

    return None, None



def actions(old_x, old_y, old_velocity_x, old_velocity_y, accelleration, environment, deterministic=False):
    if not deterministic:
        if accelleration[0] != 0 and accelleration[1] != 0 and random() > 0.8:
            print("Car failed to accelerate!")
            accelleration = (0, 0)

    y = old_velocity_x + accelleration[0]
    x = old_velocity_y + accelleration[1]
    if x < -2:
        x = -2
    if x > 2:
        x = 2
    if y < -2:
        y = -2
    if y > 2:
        y = 2

    temp_x = old_x + x
    temp_y = old_y + y
    new_x, new_y = new_position(environment, temp_x, temp_y, x, y)
    if new_y != temp_y or new_x != temp_x:
        print("Oops, it crashed. Zero speed\n")
        x, y = 0, 0
        new_y, new_x = old_y, old_x

    return new_x, new_y, x, y


def Q_policy(columns, rows, vel_r, Q):
    policyDict = {}

    for x in range(rows):
        for y in range(columns):
            for velocity_x in vel_r:
                for velocity_y in vel_r:
                    policyDict[(x, y, velocity_x, velocity_y)] = ACTIONS[np.argmax(Q[x][y][velocity_x][velocity_y])]
    return policyDict


def value_iteration(environment, reward=100.0):
    rows = len(environment)-1
    columns = len(environment[0])-1
    gamma = 0.9
    vel_r=range(-2,2+1)
    values = [[[[random() for _ in vel_r] for _ in vel_r] for _ in line] for line in environment]

    # Set the finish line states to 0
    for x in range(rows):
        for y in range(columns):
            if environment[x][y] == '2':
                for velocity_x in vel_r:
                    for velocity_y in vel_r:
                        values[x][y][velocity_x][velocity_y] = reward

    # Initialize all Q(s,a) to arbitrary values, except the terminal state
    # (i.e. finish line states) that has a value of 0. Q[x][y][velocity_x][velocity_y][ai]
    Q = [[[[[random() for _ in ACTIONS] for _ in vel_r] for _ in vel_r] for _ in line] for line in
         environment]

    # Set finish line state-action pairs
    for x in range(rows):
        for y in range(columns):
            if environment[x][y] == '2':
                for velocity_x in vel_r:
                    for velocity_y in vel_r:
                        for ai, a in enumerate(ACTIONS):
                            Q[x][y][velocity_x][velocity_y][ai] = reward


    for number_of_training in range(100):

        values_prev = deepcopy(values)

        for x in range(rows):
            for y in range(columns):
                for velocity_x in vel_r:
                    for velocity_y in vel_r:

                        # If the car crashes into a wall
                        if environment[x][y] == 'w':
                            values[x][y][velocity_x][velocity_y] = -10.0
                            continue

                        # For each action a in the set of possible actions
                        for ai, a in enumerate(ACTIONS):
                            if environment[x][y] == '2':
                                r = reward
                            else:
                                r = -1.0

                            new_x, new_y, new_velocity_x, new_velocity_y = actions(x, y, velocity_x, velocity_y, a, environment, deterministic=True)
                            value_of_new_state = values_prev[new_x][new_y][new_velocity_x][new_velocity_y]
                            new_x, new_y, new_velocity_x, new_velocity_y = actions(x, y, velocity_x, velocity_y, (0, 0), environment, deterministic=True)
                            value_of_new_state_if_action_fails = values_prev[new_x][new_y][new_velocity_x][new_velocity_y]

                            expected_value = (0.8 * value_of_new_state) + (
                                    0.2 * (value_of_new_state_if_action_fails))

                            # Update the Q-value in Q[s,a] with immediate reward + discounted future value
                            Q[x][y][velocity_x][velocity_y][ai] = r + (gamma * expected_value)

                        argMaxQ = np.argmax(Q[x][y][velocity_x][velocity_y])

                        values[x][y][velocity_x][velocity_y] = Q[x][y][velocity_x][velocity_y][argMaxQ]

        for x in range(rows):
            for y in range(columns):
                if environment[x][y] == '2':
                    for velocity_x in vel_r:
                        for velocity_y in vel_r:
                            values[x][y][velocity_x][velocity_y] = reward

        delta = max([max([max([max([abs(values[x][y][velocity_x][velocity_y] - values_prev[x][y][velocity_x][velocity_y]) for velocity_y in vel_r]) for velocity_x in (vel_r)]) for y in range(columns)]) for x in range(rows)])

        if delta < 0.001:
            return Q_policy(columns, rows, vel_r, Q), number_of_training

    return Q_policy(columns, rows, vel_r, Q), 100


def race(environment,policy):
    environment_display = deepcopy(environment)
    starting_positions = []
    for x, row in enumerate(environment):
        for y, col in enumerate(row):
            if col == '1':
                starting_positions += [(x, y)]
    start_position = choice(starting_positions)
    x, y = start_position
    velocity_x, velocity_y = 0, 0
    stop_clock = 0

    for i in range(1000):
        temp = environment_display[x][y]
        environment_display[x][y] = "X"
        time.sleep(4)
        sp.call('clear', shell=True)
        for line in environment_display:
            text = ""
            for character in line:
                text += character
            print(text)
        environment_display[x][y] = temp
        a = policy[(x, y, velocity_x, velocity_y)]  # Get the best action given the current state

        if environment[x][y] == '2':
            return i, start_position[0], start_position[1]

        print("X axis velocity:\t", velocity_x)
        print("Y axis velocity:\t", velocity_y)
        x, y, velocity_x, velocity_y = actions(x, y, velocity_x, velocity_y, a, environment)


        if velocity_y == 0 and velocity_x == 0:
            stop_clock += 1
        else:
            stop_clock = 0

        # We have gotten stuck as the car has not been moving for 10 time-steps
        if stop_clock == 10:
            return 800, None, None

    return 800, None, None


if __name__ == '__main__':
    racetrackIn=input("Give me the .txt filename containing the mapping of the race treck \t").strip()
    environment=racetrack(racetrackIn)
    number_of_races=int(input("Give me the number of races you want to simulate\t"))
    print("Training.... Please wait...\n")
    policy, training_iterations = value_iteration(environment)

    time.sleep(3)
    for i in range(number_of_races):
        print("Race Start\n")
        time.sleep(5)
        total_steps, x, y = race(environment, policy)

        if total_steps >= 500:
            print("Failed Attempt")
        else:
            print("Starting position\t",(x,y))
            print("Number of steps:\t",total_steps)
