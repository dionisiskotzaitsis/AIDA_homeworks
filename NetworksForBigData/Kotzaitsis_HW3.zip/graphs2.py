import matplotlib.pyplot as plt

def createGraph(y1,y2,y3,title,filetitle):
    plt.plot(range(len(y1)),y1,label="Random")
    plt.plot(range(len(y2)),y2,label="1D")
    plt.plot(range(len(y3)),y3,label="2D")
    plt.title(title)
    plt.legend()
    plt.savefig('./graphs/'+filetitle)
    plt.show()

if __name__ == '__main__':
    integer=int(input("Give me int\t"))
    
    rarRandomF = open('file'+str(integer)+'RandomRAR.txt', "r")
    ramRandomF = open('file'+str(integer)+'RandomRAM.txt', "r")
    cpuRandomF = open('file'+str(integer)+'RandomCPU.txt', "r")
    skewnessRandomF = open('file'+str(integer)+'RandomSkew.txt', "r")

    rar1DF = open('file' + str(integer) + '1DRAR.txt', "r")
    ram1DF = open('file' + str(integer) + '1DRAM.txt', "r")
    cpu1DF = open('file' + str(integer) + '1DCPU.txt', "r")
    skewness1DF = open('file' + str(integer) + '1DSkew.txt', "r")

    rar2DF = open('file' + str(integer) + '2DRAR.txt', "r")
    ram2DF = open('file' + str(integer) + '2DRAM.txt', "r")
    cpu2DF = open('file' + str(integer) + '2DCPU.txt', "r")
    skewness2DF = open('file' + str(integer) + '2DSkew.txt', "r")

    rarRandom = [float(i.strip()) for i in rarRandomF.readlines() if len(i.strip()) > 0]
    ramRandom = [float(i.strip()) for i in ramRandomF.readlines() if len(i.strip()) > 0]
    cpuRandom = [float(i.strip()) for i in cpuRandomF.readlines() if len(i.strip()) > 0]
    skewRandom = [float(i.strip()) for i in skewnessRandomF.readlines() if len(i.strip()) > 0]

    rar1D = [float(i.strip()) for i in rar1DF.readlines() if len(i.strip()) > 0]
    ram1D = [float(i.strip()) for i in ram1DF.readlines() if len(i.strip()) > 0]
    cpu1D = [float(i.strip()) for i in cpu1DF.readlines() if len(i.strip()) > 0]
    skew1D = [float(i.strip()) for i in skewness1DF.readlines() if len(i.strip()) > 0]

    rar2D = [float(i.strip()) for i in rar2DF.readlines() if len(i.strip()) > 0]
    ram2D = [float(i.strip()) for i in ram2DF.readlines() if len(i.strip()) > 0]
    cpu2D = [float(i.strip()) for i in cpu2DF.readlines() if len(i.strip()) > 0]
    skew2D = [float(i.strip()) for i in skewness2DF.readlines() if len(i.strip()) > 0]

    createGraph(rarRandom,rar1D,rar2D,"Request acceptance rate",'RAR'+str(integer)+'.jpg')
    createGraph(ramRandom, ram1D, ram2D, "RAM Utilization",'RAM'+str(integer)+'.jpg')
    createGraph(cpuRandom, cpu1D, cpu2D, "CPU Utilization",'CPU'+str(integer)+'.jpg')
    createGraph(skewRandom, skew1D, skew2D, "Skewness",'Skew'+str(integer)+'.jpg')