import subprocess
from subprocess import PIPE
import mininet
from time import time, sleep
from signal import SIGINT
from xmlrpc.server import SimpleXMLRPCServer
import xmlrpc.client as cl
from mininet.util import pmonitor
from mininet.topo import Topo
from mininet.net import Mininet
from mininet.node import OVSController
from mininet.util import dumpNodeConnections
from mininet.log import setLogLevel, info
from mininet.cli import CLI
from multiprocessing import Pool,Process
import math
import itertools
import sys
import random


class MyTopology(Topo):
    def build(self, n=2):
        switch = self.addSwitch("s1")
        embedder = self.addHost("embedder")
        self.addLink(embedder, switch)
        # Python's range(N) generates 0..N-1
        for h in range(n):
            host = self.addHost("server{}".format(h + 1))
            self.addLink(host, switch)


'''class MyTopo( Topo ):

    def __init__( self ):

        # Initialize topology
        Topo.__init__( self )

   
        embedder=self.addHost( 'embedder' )
        switch = self.addSwitch( 's1' )
        self.addLink(embedder, switch)
        for h in range(10):
            host = self.addHost("server{}".format(h + 1))
            self.addLink(host, switch)


        # Add hosts
'''
class Embedder:
    def __init__(self,servers):
        # Initialization of VRAM and VCPU
        self.cpu_per_ser=[1 for i in range(servers)]
        self.ram_per_ser=[1 for i in range(servers)]
        # Count the responses
        self.responses=[0,0]
        # Request lists
        self.ram_requests=[]
        self.cpu_requests=[]
        # Allocations per request
        self.memoryAlloc=[]
        self.cpuAlloc=[]

        self.NumOfRequests = 8 * servers
    
    def generator(self):
        listOfRam=[]
        listOfCpu=[]
        for i in range(self.NumOfRequests):
            listOfRam.append(random.uniform(0.05,0.2))
            listOfCpu.append(random.uniform(0.05,0.2))
        
        self.ram_requests=listOfRam
        self.cpu_requests=listOfCpu


    def getResponse(self,response):
        rspList=response.split(",")
        print(rspList)
        #print(rspList[0].split()[1])
        return (rspList[0].split()[1], float(rspList[1].strip()),float(rspList[2].strip()))

    def countAcceptDenied(self,respondingCall):
        if respondingCall=="True":
            self.responses[0]+=1
        else:
            self.responses[1]+=1
        print(self.responses)

    
    def newServerCapabilities(self,index,cpu_val,ram_val):
        self.cpu_per_ser[index]=cpu_val
        self.ram_per_ser[index]=ram_val


    
        



def run(*popenargs, **kwargs):
    input = kwargs.pop("input", None)
    check = kwargs.pop("handle", False)

    if input is not None:
        if 'stdin' in kwargs:
            raise ValueError('stdin and input arguments may not both be used.')
        kwargs['stdin'] = subprocess.PIPE

    process = subprocess.Popen(*popenargs, **kwargs)
    try:
        stdout, stderr = process.communicate(input)
    except:
        process.kill()
        process.wait()
        raise
    retcode = process.poll()
    if check and retcode:
        raise subprocess.CalledProcessError(
            retcode, process.args, output=stdout, stderr=stderr)
    return retcode, stdout, stderr



def masterDef(servers,filenameArray):
    files = {i: open(i, 'w+') for i in filenameArray}
    print(int(servers))
    # Because of Python 3.4.3 I cant use subprocess.run. . . 
    output = run(["sudo", "mn", "-c"])

    topo = MyTopology(int(servers))

    
    net = Mininet(topo,controller=OVSController)
    net.start()
    print("Dumping host connections")
    dumpNodeConnections(net.hosts)
    #net.pingAll()
    host_embedder = net.get("embedder")
    serversList = net.hosts
    serversList = serversList[1:] 

    ################# Random Method ####################


    print("############### RANDOM METHOD ####################\n")
    embedder=Embedder(int(servers))
    embedder.generator()
    acceptanceRate,ramUtilization,cpuUtilization,skewness=[],[],[],[]
    for rr in range(len(embedder.ram_requests)):
        index=random.randrange(len(embedder.ram_per_ser))
        command=serversList[index].popen("sudo python3 server.py")
        sleep(1)
        cmdPrintCommand="sudo python3 client.py "+(serversList[index].IP())+" "+str(embedder.cpu_per_ser[index])+" "+str(embedder.cpu_requests[rr])+" "+str(embedder.ram_per_ser[index])+" "+str(embedder.ram_requests[rr])
        print(cmdPrintCommand)

        resulting_response=host_embedder.cmdPrint(cmdPrintCommand)
        client_response,cpu_new,ram_new=embedder.getResponse(resulting_response) 

        embedder.countAcceptDenied(client_response)
        embedder.newServerCapabilities(index,cpu_new,ram_new)
        ###########################
        acceptanceRate.append(embedder.responses[0]/(embedder.responses[0]+embedder.responses[1]))
        files['file'+str(int(servers))+'RandomRAR.txt'].write(str(embedder.responses[0]/(embedder.responses[0]+embedder.responses[1]))+'\n')
        cpuUt=[1-i for i in embedder.cpu_per_ser]
        ramUt=[1-i for i in embedder.ram_per_ser]
        cpuUtilization.append(sum(cpuUt)/len(cpuUt))
        ramUtilization.append(sum(ramUt)/len(ramUt))
        files['file'+str(int(servers))+'RandomCPU.txt'].write(str(sum(cpuUt)/len(cpuUt))+'\n')
        files['file'+str(int(servers))+'RandomRAM.txt'].write(str(sum(ramUt)/len(ramUt))+'\n')
        resArr=[]
        meanOfArr=[]
        for i in range(int(servers)):
            resArr.append([embedder.cpu_per_ser[i],embedder.ram_per_ser[i]])
            meanOfArr.append((embedder.cpu_per_ser[i]+embedder.ram_per_ser[i])/2)
        '''meanOfArr=[]
        for i in resArr:
            nominator=i[0]+i[1]
            meanOfArr+=nominator
        meanOfArr/=2'''

        outsideSum=0
        for i in range(int(servers)):
            insideSum=0
            for j in range(2):
                insideSum+=((resArr[i][j]/meanOfArr[i])-1)**2
            outsideSum+=math.sqrt(insideSum)
        skewness.append(outsideSum/len(servers))
        files['file'+str(int(servers))+'RandomSkew.txt'].write(str(outsideSum/len(servers))+'\n')
        ###########################
        command.terminate()


    print(len(acceptanceRate),len(ramUtilization),len(cpuUtilization),len(skewness))
    '''
    acceptanceRate=embedder.responses[0]/(embedder.responses[0]+embedder.responses[1])
    print(acceptanceRate)
    fileSer.write(str(acceptanceRate)+"\n")
    cpuUt=[1-i for i in embedder.cpu_per_ser]
    ramUt=[1-i for i in embedder.ram_per_ser]
    cpuUtilization=sum(cpuUt)/len(cpuUt)
    ramUtilization=sum(ramUt)/len(ramUt)
    print(cpuUtilization,ramUtilization)
    fileSer.write(str(cpuUtilization)+"\n")
    fileSer.write(str(ramUtilization)+"\n")



    resArr=[]
    for i in range(int(servers)):
        resArr.append([embedder.cpu_per_ser[i],embedder.ram_per_ser[i]])
    
    meanOfArr=0
    for i in resArr:
        nominator=i[0]+i[1]
        meanOfArr+=nominator
    meanOfArr/=len(resArr)

    outsideSum=0
    for i in range(int(servers)):
        insideSum=0
        for j in range(2):
            insideSum+=((resArr[i][j]/meanOfArr)-1)**2
        outsideSum+=math.sqrt(insideSum)
    skewness=outsideSum/len(servers)
    print(skewness)
    fileSer.write(str(skewness)+"\n")'''

    ################ Best 1d fit Method ####################


    print("############### BEST 1D FIT METHOD ####################\n")

    embedder2=Embedder(int(servers))
    embedder2.generator()
    acceptanceRate,ramUtilization,cpuUtilization,skewness=[],[],[],[]

    for rr in range(len(embedder2.ram_requests)):
        inxArr=[]

        embedder2.cpu_per_ser.sort()
        for i in range(len(embedder2.cpu_per_ser)):
            if embedder2.cpu_per_ser[i]>=embedder2.cpu_requests[rr] and embedder2.ram_per_ser[i]>=embedder2.ram_requests[rr]:
                inxArr.append(i)
            else:
                continue
        if len(inxArr)!=0:
            index=inxArr[0]
        else:
            index=random.randrange(len(embedder.ram_per_ser))
        #index=embedder2.cpu_per_ser.index(min(inxArr))
        command=serversList[index].popen("sudo python3 server.py")
        sleep(1)
        cmdPrintCommand="sudo python3 client.py "+(serversList[index].IP())+" "+str(embedder2.cpu_per_ser[index])+" "+str(embedder2.cpu_requests[rr])+" "+str(embedder2.ram_per_ser[index])+" "+str(embedder2.ram_requests[rr])
        print(cmdPrintCommand)

        resulting_response=host_embedder.cmdPrint(cmdPrintCommand)
        client_response,cpu_new,ram_new=embedder2.getResponse(resulting_response) 

        embedder2.countAcceptDenied(client_response)
        embedder2.newServerCapabilities(index,cpu_new,ram_new)
        ########################
        acceptanceRate.append(embedder2.responses[0]/(embedder2.responses[0]+embedder2.responses[1]))
        files['file'+str(int(servers))+'1DRAR.txt'].write(str(embedder2.responses[0]/(embedder2.responses[0]+embedder2.responses[1]))+'\n')
        
        cpuUt=[1-i for i in embedder2.cpu_per_ser]
        ramUt=[1-i for i in embedder2.ram_per_ser]
        cpuUtilization.append(sum(cpuUt)/len(cpuUt))
        ramUtilization.append(sum(ramUt)/len(ramUt))
        files['file'+str(int(servers))+'1DCPU.txt'].write(str(sum(cpuUt)/len(cpuUt))+'\n')
        files['file'+str(int(servers))+'1DRAM.txt'].write(str(sum(ramUt)/len(ramUt))+'\n')
        resArr=[]
        meanOfArr=[]
        for i in range(int(servers)):
            resArr.append([embedder2.cpu_per_ser[i],embedder2.ram_per_ser[i]])
            meanOfArr.append((embedder2.cpu_per_ser[i]+embedder2.ram_per_ser[i])/2)
        '''meanOfArr=[]
        for i in resArr:
            nominator=i[0]+i[1]
            meanOfArr+=nominator
        meanOfArr/=2'''

        outsideSum=0
        for i in range(int(servers)):
            insideSum=0
            for j in range(2):
                insideSum+=((resArr[i][j]/meanOfArr[i])-1)**2
            outsideSum+=math.sqrt(insideSum)
        skewness.append(outsideSum/len(servers))
        files['file'+str(int(servers))+'1DSkew.txt'].write(str(outsideSum/len(servers))+'\n')
        ##########################
        command.terminate()

    
    #acceptanceRate=embedder2.responses[0]/(embedder2.responses[0]+embedder2.responses[1])
    #print(acceptanceRate)
    #fileSer.write("\n")
    #fileSer.write(str(acceptanceRate)+"\n")
    print(len(acceptanceRate),len(ramUtilization),len(cpuUtilization),len(skewness))
    '''
    cpuUt=[1-i for i in embedder2.cpu_per_ser]
    ramUt=[1-i for i in embedder2.ram_per_ser]
    cpuUtilization=sum(cpuUt)/len(cpuUt)
    ramUtilization=sum(ramUt)/len(ramUt)
    print(cpuUtilization,ramUtilization)
    fileSer.write(str(cpuUtilization)+"\n")
    fileSer.write(str(ramUtilization)+"\n")'''

    '''    resArr=[]
    for i in range(int(servers)):
        resArr.append([embedder2.cpu_per_ser[i],embedder2.ram_per_ser[i]])
    
    meanOfArr=0
    for i in resArr:
        nominator=i[0]+i[1]
        meanOfArr+=nominator
    meanOfArr/=2

    outsideSum=0
    for i in range(int(servers)):
        insideSum=0
        for j in range(2):
            insideSum+=((resArr[i][j]/meanOfArr)-1)**2
        outsideSum+=math.sqrt(insideSum)
    skewness=outsideSum/len(servers)'''
    #print(skewness)
    #fileSer.write(str(skewness)+"\n")



    print("############### BEST 2D FIT METHOD ####################\n")
    
    embedder3=Embedder(int(servers))
    embedder3.generator()

    acceptanceRate,ramUtilization,cpuUtilization,skewness=[],[],[],[]

    for rr in range(len(embedder3.ram_requests)):
        indxArr=[]
        reqVec=[embedder3.cpu_requests[rr],embedder3.ram_requests[rr]]
        for i in range(len(embedder3.cpu_per_ser)):
            if embedder3.cpu_per_ser[i]>=embedder3.cpu_requests[rr] and embedder3.ram_per_ser[i]>=embedder3.ram_requests[rr]:
                availVec=[embedder3.cpu_per_ser[i],embedder3.ram_per_ser[i]]
                sumxx, sumxy, sumyy = 0, 0, 0
                for j in range(len(availVec)):
                    x=reqVec[j]
                    y=availVec[j]
                    sumxx += x*x
                    sumyy += y*y
                    sumxy += x*y
                indxArr.append(sumxy/math.sqrt(sumxx*sumyy))
            else:
                indxArr.append(-999999999)
        
        index=indxArr.index(max(indxArr))
        if indxArr[index]<-1:
            index=random.randrange(len(embedder.ram_per_ser))
        print(indxArr,'\t',index)
        


        command=serversList[index].popen("sudo python3 server.py")
        sleep(1)
        cmdPrintCommand="sudo python3 client.py "+(serversList[index].IP())+" "+str(embedder3.cpu_per_ser[index])+" "+str(embedder3.cpu_requests[rr])+" "+str(embedder3.ram_per_ser[index])+" "+str(embedder3.ram_requests[rr])
        print(cmdPrintCommand)

        resulting_response=host_embedder.cmdPrint(cmdPrintCommand)
        client_response,cpu_new,ram_new=embedder3.getResponse(resulting_response) 

        embedder3.countAcceptDenied(client_response)
        embedder3.newServerCapabilities(index,cpu_new,ram_new)

        ########################
        acceptanceRate.append(embedder3.responses[0]/(embedder3.responses[0]+embedder3.responses[1]))
        files['file'+str(int(servers))+'2DRAR.txt'].write(str(embedder3.responses[0]/(embedder3.responses[0]+embedder3.responses[1]))+'\n')

        cpuUt=[1-i for i in embedder3.cpu_per_ser]
        ramUt=[1-i for i in embedder3.ram_per_ser]
        cpuUtilization.append(sum(cpuUt)/len(cpuUt))
        ramUtilization.append(sum(ramUt)/len(ramUt))
        files['file'+str(int(servers))+'2DCPU.txt'].write(str(sum(cpuUt)/len(cpuUt))+'\n')
        files['file'+str(int(servers))+'2DRAM.txt'].write(str(sum(ramUt)/len(ramUt))+'\n')
        resArr=[]
        meanOfArr=[]
        for i in range(int(servers)):
            resArr.append([embedder3.cpu_per_ser[i],embedder3.ram_per_ser[i]])
            meanOfArr.append((embedder3.cpu_per_ser[i]+embedder3.ram_per_ser[i])/2)
        '''meanOfArr=[]
        for i in resArr:
            nominator=i[0]+i[1]
            meanOfArr+=nominator
        meanOfArr/=2'''

        outsideSum=0
        for i in range(int(servers)):
            insideSum=0
            for j in range(2):
                insideSum+=((resArr[i][j]/meanOfArr[i])-1)**2
            outsideSum+=math.sqrt(insideSum)
        skewness.append(outsideSum/len(servers))
        files['file'+str(int(servers))+'2DSkew.txt'].write(str(outsideSum/len(servers))+'\n')

        ##########################


        command.terminate()

    print(len(acceptanceRate),len(ramUtilization),len(cpuUtilization),len(skewness))

    '''
    acceptanceRate=embedder3.responses[0]/(embedder3.responses[0]+embedder3.responses[1])
    print(acceptanceRate)
    fileSer.write("\n")
    fileSer.write(str(acceptanceRate)+"\n")


    cpuUt=[1-i for i in embedder3.cpu_per_ser]
    ramUt=[1-i for i in embedder3.ram_per_ser]
    cpuUtilization=sum(cpuUt)/len(cpuUt)
    ramUtilization=sum(ramUt)/len(ramUt)
    print(cpuUtilization,ramUtilization)
    fileSer.write(str(cpuUtilization)+"\n")
    fileSer.write(str(ramUtilization)+"\n")


    resArr=[]
    for i in range(int(servers)):
        resArr.append([embedder3.cpu_per_ser[i],embedder3.ram_per_ser[i]])
    
    meanOfArr=0
    for i in resArr:
        nominator=i[0]+i[1]
        meanOfArr+=nominator
    meanOfArr/=len(resArr)

    outsideSum=0
    for i in range(int(servers)):
        insideSum=0
        for j in range(2):
            insideSum+=((resArr[i][j]/meanOfArr)-1)**2
        outsideSum+=math.sqrt(insideSum)
    skewness=outsideSum/len(servers)
    print(skewness)
    fileSer.write(str(skewness)+"\n")'''


    for path in files:
        files[path].close()

    net.stop()




if __name__=="__main__":
    NumOfServers = sys.argv[1]
    filenameArray=['file'+str(NumOfServers)+'RandomRAR.txt','file'+str(NumOfServers)+'RandomRAM.txt','file'+str(NumOfServers)+'RandomCPU.txt','file'+str(NumOfServers)+'RandomSkew.txt','file'+str(NumOfServers)+'1DRAR.txt','file'+str(NumOfServers)+'1DRAM.txt','file'+str(NumOfServers)+'1DCPU.txt','file'+str(NumOfServers)+'1DSkew.txt','file'+str(NumOfServers)+'2DRAR.txt','file'+str(NumOfServers)+'2DRAM.txt','file'+str(NumOfServers)+'2DCPU.txt','file'+str(NumOfServers)+'2DSkew.txt']
    #filename='file'+str(NumOfServers)+'servers.txt'
    masterDef(NumOfServers,filenameArray)