from xmlrpc.server import SimpleXMLRPCServer


class MyServer:

    def check(self, cpu_avail, cpu_req, ram_avail, ram_req):
        if cpu_req <= cpu_avail and ram_avail>= ram_req:
            cpu_avail -= cpu_req 
            ram_avail -= ram_req
            responding = True
        else:
            responding = False

        return responding, cpu_avail, ram_avail

server = SimpleXMLRPCServer(("", 8200))
print("server serving...")
server.register_instance(MyServer())
server.serve_forever()