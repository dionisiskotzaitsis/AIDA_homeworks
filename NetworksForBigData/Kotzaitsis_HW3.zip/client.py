import xmlrpc.client

import sys


ip, current_cpu, new_req, current_ram, new_ram_req = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5]

proxy = xmlrpc.client.ServerProxy("http://" + str(ip) + ":8200/")
print("http://" + str(ip) + ":8200/")

ack,cpu_new,ram_new = proxy.check(float(current_cpu), float(new_req),float(current_ram), float(new_ram_req))
print("{},{},{}".format(ack,cpu_new,ram_new))