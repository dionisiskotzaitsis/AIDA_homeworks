############ Tutorial ##############


How to run the code:
-> Need python 3 (https://www.python.org/downloads/)
-> Go to Terminal
-> Run: cd ./path_to_file_directory
-> Run: python3 hw_2_Kotzaitsis.py
---> The program waits for your input, so you need to input the filename (WITHOUT .pcap)

####################################
You also need:
-> dpkt: https://dpkt.readthedocs.io/en/latest/
---> To download: pip3 install dpkt

-> numpy: https://numpy.org/
---> To download: pip3 install numpy

-> matplotlib: https://matplotlib.org/
---> To download: pip3 install matplotlib

