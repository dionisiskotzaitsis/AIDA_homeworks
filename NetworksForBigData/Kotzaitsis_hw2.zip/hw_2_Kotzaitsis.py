import dpkt
import socket
import matplotlib.pyplot as plt
import collections
import numpy as np
import pandas as pd


def parser(filename):
    '''
    :param filename: Gets the .pcap file as input from the user (in main)
    :return: The binary .pcap file
    '''
    f=open(filename+'.pcap','rb')
    trace=dpkt.pcap.Reader(f)

    return trace



def analysis(trace):
    '''
    Analysis function of pcap file. Parsing each packet and get its type.
    We also start the flow handling
    :param trace: the file
    :return:
    '''

    # We create a dictionary for "saving" the flow data
    flows = {}

    # Packet Counters
    icmp_p = 0
    tcp_p = 0
    udp_p = 0
    arp_p = 0
    other_p = 0

    # Dictionary for packet size
    packetSize = {}

    print("Parsing through the file. . . .\n")
    for ts,pkt in trace:

        eth = dpkt.ethernet.Ethernet(pkt)

        # Handle IP packets
        if type(eth.data) == dpkt.ip.IP:
            ip = eth.data
            size = ip.len

            # Now we want to check what kind of packet we have. If we have a UDP, TCP or ICMP packet
            if ip.p == dpkt.ip.IP_PROTO_UDP or ip.p == dpkt.ip.IP_PROTO_TCP:
                flows,tcp_p,udp_p,packetSize=flowHandler(pkt,ts,tcp_p,udp_p,flows,packetSize,ip,size)
            elif ip.p == dpkt.ip.IP_PROTO_ICMP:
                icmp_p += 1


        # Check if the packet is an ARP packet
        elif eth.type == dpkt.ethernet.ETH_TYPE_ARP:
                arp_p += 1

        # Other packets
        else:
            other_p+=1

    for i in flows:
        flowTime(flows,i)


    for i in packetSize:
        packetSize[i] = packetSize[i] / (udp_p+tcp_p)

    total_count = icmp_p + udp_p + tcp_p + arp_p + other_p

    # Calculate the percentage of each packet type.
    percentages=[]
    count=[udp_p,tcp_p,icmp_p,arp_p,other_p]
    percentages.append(udp_p / total_count)
    percentages.append(tcp_p / total_count)
    percentages.append(icmp_p / total_count)
    percentages.append(arp_p / total_count)
    percentages.append(other_p / total_count)

    # Finally lets get the flow size and duration distribution
    flowSize = {}
    flowDuration = {}

    flowSize, flowDuration = distributions(flows, flowSize, flowDuration)

    #print(percentages)
    #print(flows,"\n",total_count)

    return flows,flowSize,flowDuration,percentages,total_count,packetSize,count



def flowHandler(pkt,ts,tcp_p,udp_p,flows,packetSize,ip,size):
    '''
    Here we handle the packets and create a dictionary that represents our flow, based on the packet headers
    :param pkt: packet
    :param ts: timestamp of the packet
    :param tcp_p: tcp packet counter
    :param udp_p: udp packet counter
    :param flows: the dict
    :param packetSize: a dict for the size of our packets
    :param ip: the ip data from dpkt library
    :param size: the size of the packet
    :return: the dictionary and the counts of tcp, udp and the packet size dict
    '''

    # Get the IP addresses and ports of destination and source
    sourceIP = socket.inet_ntoa(ip.src)
    sourcePort = ip.data.sport
    destinationIP = socket.inet_ntoa(ip.dst)
    destinationPort = ip.data.dport

    # UPD and TCP counters and create the labels
    if ip.p == dpkt.ip.IP_PROTO_UDP:
        udp_p += 1
        label = "udp"
    else:
        tcp_p += 1
        label = "tcp"

    # We create a set for our packet Header,
    flowHeader = (label, sourceIP, sourcePort, destinationIP, destinationPort)
    # print(flowHeader)

    # For every packet we insert into the dictionary, we check if there is a "duplicate" of the header
    # If there is, then we have already created a flow, and we just add the new packet, by changing the start or/and
    # timestamps and adding the size of the new packet to the flow size.
    # Else, a new packet is created.

    if flowHeader not in flows:

        flows[flowHeader]={}
        flows[flowHeader]["startT"]=ts
        flows[flowHeader]["endT"]=ts
        flows[flowHeader]["size"]=size

    else:
        flows[flowHeader]["size"] = flows[flowHeader]["size"] + size

        if ts > flows[flowHeader]["endT"]:
            flows[flowHeader]["endT"] = ts
        elif ts < flows[flowHeader]["startT"]:
            flows[flowHeader]["startT"] = ts

    if size not in packetSize:
        packetSize[size] = 1
    else:
        packetSize[size] += 1



    return flows,tcp_p,udp_p,packetSize



def flowTime(flows,i):
    '''
    :param flows: gets the flows dictionary
    :param i: gets the flow index
    :return: the time difference between sending the first and last packet
    '''
    flows[i]["diffT"]=flows[i]["endT"]-flows[i]["startT"]



def distributions(flows,flowSize,flowDuration):
    '''
    We calculate the size and duration distributions for our flows
    :param flows: the flow dictionary
    :param flowSize: the flow size dictionary
    :param flowDuration: the flow duration dictionary
    :return: the updated flowSize and flowDuration
    '''
    for j in flows:
        sizeF = flows[j]["size"]
        timeF = flows[j]["diffT"]
        if sizeF not in flowSize:
            flowSize[sizeF] = 1
        else:
            flowSize[sizeF] += 1

        if timeF not in flowDuration:
            flowDuration[timeF] = 1
        else:
            flowDuration[timeF] += 1

    for key in flowSize:
        flowSize[key]=flowSize[key]/len(flows)

    for key in flowDuration:
        flowDuration[key]=flowDuration[key]/len(flows)

    return flowSize, flowDuration



def plots(flows,flowS,flowD,probabilities,packetSize,count):
    '''
    Here we plot all of our distributions.
    For the CDFs, we sort the dict by keys and then we add the values to create the cumulative distr.
    :param flows: our flows dict
    :param flowS: our flow size dict
    :param flowD: our flow duration dict
    :param packetSize: the packet sizes in a dict
    :param count: the count list of packets
    :return: 0
    '''


    # CDF for packet sizes
    packSizeSort = collections.OrderedDict(sorted(packetSize.items()))
    cumulativeX = list((packSizeSort.keys()))
    cumulativeY = np.cumsum(list(packSizeSort.values()))

    plt.xlabel('Packet Size')
    plt.ylabel('CDF')

    plt.title('Packet Size CDF in bytes')

    plt.plot(cumulativeX, cumulativeY, marker='o')
    plt.xlim(0, 2000)
    plt.savefig('packetCDF.png')
    plt.show()

    # CDF for flow size
    sortFlowS = collections.OrderedDict(sorted(flowS.items()))
    cumulativeX=list((sortFlowS.keys()))
    cumulativeY=np.cumsum(list(sortFlowS.values()))

    plt.xlabel('Flow Size')
    plt.ylabel('CDF')

    plt.title('Flow Size CDF')

    plt.plot(cumulativeX, cumulativeY, marker='o')
    plt.xlim(0,13000)
    plt.savefig('flowSizeCDF.png')
    plt.show()


    # PDF for flow size
    sortFlowS = collections.OrderedDict(sorted(flowS.items()))
    cumulativeX = list((sortFlowS.keys()))
    cumulativeY = (list(sortFlowS.values()))

    plt.xlabel('Flow Size')
    plt.ylabel('PDF')

    plt.title('Flow Size PDF')

    plt.plot(cumulativeX, cumulativeY, marker='o')
    plt.xlim(0, 13000)
    plt.savefig('flowSizePDF.png')
    plt.show()


    # Flow Duration CDF
    sortFlowD = collections.OrderedDict(sorted(flowD.items()))
    cumulativeX = list((sortFlowD.keys()))
    cumulativeY = np.cumsum(list(sortFlowD.values()))

    plt.xlabel('Flow Duration')
    plt.ylabel('CDF')

    plt.title('Duration Flow CDF')

    plt.plot(cumulativeX, cumulativeY, marker='o')
    plt.savefig('flowDurationCDF.png')
    plt.show()

    # Flow Duration PDF
    sortFlowD = collections.OrderedDict(sorted(flowD.items()))
    cumulativeX = list((sortFlowD.keys()))
    cumulativeY = (list(sortFlowD.values()))

    plt.xlabel('Flow Duration')
    plt.ylabel('PDF')

    plt.title('Duration Flow PDF')

    plt.plot(cumulativeX, cumulativeY, marker='o')
    plt.savefig('flowDurationPDF.png')
    plt.show()

    # Protocol percentage barplot
    table=["udp","tcp","icmp","arp","other"]
    plt.bar(table,(probabilities))
    plt.title("Protocol Percentage")
    plt.ylabel("Percentage per protocol")
    plt.xlabel("Protocol")
    for i in range(len(probabilities)):
        plt.text(i, probabilities[i], "{:.6f}".format(probabilities[i]))

    plt.savefig('protoPercentage.png')
    plt.show()

    # Protocol percentage barplot
    table = ["udp", "tcp", "icmp", "arp", "other"]
    plt.bar(table, (count))
    plt.title("Protocol Count")
    plt.ylabel("Count per protocol")
    plt.xlabel("Protocol")
    for i in range(len(count)):
        plt.text(i, count[i], "{:.1f}".format(count[i]))

    plt.savefig('protoCount.png')
    plt.show()

    return 0



def main():
    '''
    :MAIN:
    '''
    filename=str(input("Give me your .pcap filename\n"))
    trace=parser(filename)
    flows, flowSize, flowDuration, percentages, total_count,packetSize,count = analysis(trace)
    print("Time to plot . . .\n")
    plots(flows,flowSize,flowDuration,percentages,packetSize,count)
    flows = pd.DataFrame.from_dict(flows, orient="index")
    flowSize = pd.DataFrame.from_dict(flowSize, orient="index")
    flowDuration = pd.DataFrame.from_dict(flowDuration, orient="index")
    packetSize = pd.DataFrame.from_dict(packetSize, orient="index")
    print("File analysis . . .\n")
    print("Flows\n",flows, "\n","Flow Size\n", flowSize, "\n","Flow Duration\n", flowDuration, "\n","Perecentages\n", percentages, "\n","Total Count \n" ,total_count, "\n","Packet Sizes\n", packetSize)

if __name__ == '__main__':
    main()
