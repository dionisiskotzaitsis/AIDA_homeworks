#1<->5
sudo ovs-ofctl add-flow s31 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:05,nw_ttl=64,actions=mod_dl_src:22:33:00:00:00:00,dec_ttl,output:1
sudo ovs-ofctl add-flow s33 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:01,nw_ttl=64,actions=mod_dl_src:11:33:00:00:00:00,dec_ttl,output:1
#2<->6
sudo ovs-ofctl add-flow s31 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:06,nw_ttl=64,actions=mod_dl_src:22:34:00:00:00:00,dec_ttl,output:1
sudo ovs-ofctl add-flow s33 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:02,nw_ttl=64,actions=mod_dl_src:11:34:00:00:00:00,dec_ttl,output:1
#3<->7
sudo ovs-ofctl add-flow s32 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:07,nw_ttl=64,actions=mod_dl_src:22:43:00:00:00:00,dec_ttl,output:1
sudo ovs-ofctl add-flow s34 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:03,nw_ttl=64,actions=mod_dl_src:11:43:00:00:00:00,dec_ttl,output:1
#4<->8
sudo ovs-ofctl add-flow s32 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:08,nw_ttl=64,actions=mod_dl_src:22:44:00:00:00:00,dec_ttl,output:1
sudo ovs-ofctl add-flow s34 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:04,nw_ttl=64,actions=mod_dl_src:11:44:00:00:00:00,dec_ttl,output:1
#5<->9
sudo ovs-ofctl add-flow s33 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:09,nw_ttl=64,actions=mod_dl_src:23:33:00:00:00:00,dec_ttl,output:1
sudo ovs-ofctl add-flow s35 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:05,nw_ttl=64,actions=mod_dl_src:12:33:00:00:00:00,dec_ttl,output:1
#6<->10
sudo ovs-ofctl add-flow s33 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:0a,nw_ttl=64,actions=mod_dl_src:23:34:00:00:00:00,dec_ttl,output:1
sudo ovs-ofctl add-flow s35 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:06,nw_ttl=64,actions=mod_dl_src:12:34:00:00:00:00,dec_ttl,output:1
#7->11
sudo ovs-ofctl add-flow s34 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:0b,nw_ttl=64,actions=mod_dl_src:13:43:00:00:00:00,dec_ttl,output:2
sudo ovs-ofctl add-flow s36 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:07,nw_ttl=64,actions=mod_dl_src:12:43:00:00:00:00,dec_ttl,output:2
#8<->12
sudo ovs-ofctl add-flow s34 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:0c,nw_ttl=64,actions=mod_dl_src:13:44:00:00:00:00,dec_ttl,output:2
sudo ovs-ofctl add-flow s36 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:08,nw_ttl=64,actions=mod_dl_src:12:44:00:00:00:00,dec_ttl,output:2
#9<->13
sudo ovs-ofctl add-flow s35 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:0d,nw_ttl=64,actions=mod_dl_src:24:33:00:00:00:00,dec_ttl,output:1
sudo ovs-ofctl add-flow s37 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:09,nw_ttl=64,actions=mod_dl_src:23:33:00:00:00:00,dec_ttl,output:1
#10<->14
sudo ovs-ofctl add-flow s35 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:0e,nw_ttl=64,actions=mod_dl_src:24:34:00:00:00:00,dec_ttl,output:1
sudo ovs-ofctl add-flow s37 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:0a,nw_ttl=64,actions=mod_dl_src:23:34:00:00:00:00,dec_ttl,output:1
#11<->15
sudo ovs-ofctl add-flow s36 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:0f,nw_ttl=64,actions=mod_dl_src:24:43:00:00:00:00,dec_ttl,output:2
sudo ovs-ofctl add-flow s38 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:0b,nw_ttl=64,actions=mod_dl_src:13:43:00:00:00:00,dec_ttl,output:2
#12<->16
sudo ovs-ofctl add-flow s36 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:10,nw_ttl=64,actions=mod_dl_src:24:44:00:00:00:00,dec_ttl,output:2
sudo ovs-ofctl add-flow s38 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:0c,nw_ttl=64,actions=mod_dl_src:13:44:00:00:00:00,dec_ttl,output:2

sudo ovs-ofctl add-flow s21 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s21 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s21 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s21 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s21 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s21 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]




sudo ovs-ofctl add-flow s22 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s22 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s22 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s22 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s22 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s22 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]




sudo ovs-ofctl add-flow s23 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s23 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s23 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s23 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s23 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s23 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]




sudo ovs-ofctl add-flow s24 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s24 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s24 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s24 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s24 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s24 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]




sudo ovs-ofctl add-flow s25 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s25 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s25 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s25 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s25 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s25 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]




sudo ovs-ofctl add-flow s26 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s26 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s26 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s26 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s26 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s26 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]



sudo ovs-ofctl add-flow s27 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s27 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s27 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s27 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s27 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s27 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]



sudo ovs-ofctl add-flow s28 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s28 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s28 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s28 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s28 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s28 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]



sudo ovs-ofctl add-flow s11 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s11 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s11 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s11 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s11 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s11 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]



sudo ovs-ofctl add-flow s12 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s12 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s12 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s12 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s12 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s12 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]



sudo ovs-ofctl add-flow s13 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s13 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s13 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s13 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s13 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s13 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]



sudo ovs-ofctl add-flow s14 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s14 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s14 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s14 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s14 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s14 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]


sudo ovs-ofctl add-flow s31 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s31 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s31 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s31 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s31 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s31 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]

sudo ovs-ofctl add-flow s32 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s32 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s32 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s32 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s32 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s32 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]

sudo ovs-ofctl add-flow s33 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s33 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s33 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s33 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s33 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s33 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]

sudo ovs-ofctl add-flow s34 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s34 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s34 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s34 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s34 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s34 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]

sudo ovs-ofctl add-flow s35 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s35 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s35 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s35 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s35 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s35 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]

sudo ovs-ofctl add-flow s36 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s36 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s36 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s36 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s36 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s36 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]

sudo ovs-ofctl add-flow s37 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s37 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s37 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s37 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s37 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s37 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]

sudo ovs-ofctl add-flow s38 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s38 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s38 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s38 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s38 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s38 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]

