# 1 -> 5
sudo ovs-ofctl add-flow s31 dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:05,actions=output:1
sudo ovs-ofctl add-flow s21 dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:05,actions=output:2
sudo ovs-ofctl add-flow s12 dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:05,actions=output:2
sudo ovs-ofctl add-flow s23 dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:05,actions=output:3
sudo ovs-ofctl add-flow s33 dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:05,actions=output:3
# 5 -> 1
sudo ovs-ofctl add-flow s31 dl_src=00:00:00:00:00:05,dl_dst=00:00:00:00:00:01,actions=output:3
sudo ovs-ofctl add-flow s21 dl_src=00:00:00:00:00:05,dl_dst=00:00:00:00:00:01,actions=output:3
sudo ovs-ofctl add-flow s12 dl_src=00:00:00:00:00:05,dl_dst=00:00:00:00:00:01,actions=output:1
sudo ovs-ofctl add-flow s23 dl_src=00:00:00:00:00:05,dl_dst=00:00:00:00:00:01,actions=output:1
sudo ovs-ofctl add-flow s33 dl_src=00:00:00:00:00:05,dl_dst=00:00:00:00:00:01,actions=output:1
# 2 -> 6
sudo ovs-ofctl add-flow s31 dl_src=00:00:00:00:00:02,dl_dst=00:00:00:00:00:06,actions=output:1
sudo ovs-ofctl add-flow s21 dl_src=00:00:00:00:00:02,dl_dst=00:00:00:00:00:06,actions=output:2
sudo ovs-ofctl add-flow s12 dl_src=00:00:00:00:00:02,dl_dst=00:00:00:00:00:06,actions=output:2
sudo ovs-ofctl add-flow s23 dl_src=00:00:00:00:00:02,dl_dst=00:00:00:00:00:06,actions=output:3
sudo ovs-ofctl add-flow s33 dl_src=00:00:00:00:00:02,dl_dst=00:00:00:00:00:06,actions=output:4
# 6 -> 2
sudo ovs-ofctl add-flow s31 dl_src=00:00:00:00:00:06,dl_dst=00:00:00:00:00:02,actions=output:4
sudo ovs-ofctl add-flow s21 dl_src=00:00:00:00:00:06,dl_dst=00:00:00:00:00:02,actions=output:3
sudo ovs-ofctl add-flow s12 dl_src=00:00:00:00:00:06,dl_dst=00:00:00:00:00:02,actions=output:1
sudo ovs-ofctl add-flow s23 dl_src=00:00:00:00:00:06,dl_dst=00:00:00:00:00:02,actions=output:1
sudo ovs-ofctl add-flow s33 dl_src=00:00:00:00:00:06,dl_dst=00:00:00:00:00:02,actions=output:1
# 3 -> 7
sudo ovs-ofctl add-flow s32 dl_src=00:00:00:00:00:03,dl_dst=00:00:00:00:00:07,actions=output:1
sudo ovs-ofctl add-flow s21 dl_src=00:00:00:00:00:03,dl_dst=00:00:00:00:00:07,actions=output:2
sudo ovs-ofctl add-flow s12 dl_src=00:00:00:00:00:03,dl_dst=00:00:00:00:00:07,actions=output:2
sudo ovs-ofctl add-flow s23 dl_src=00:00:00:00:00:03,dl_dst=00:00:00:00:00:07,actions=output:4
sudo ovs-ofctl add-flow s34 dl_src=00:00:00:00:00:03,dl_dst=00:00:00:00:00:07,actions=output:3
# 7 -> 3
sudo ovs-ofctl add-flow s32 dl_src=00:00:00:00:00:07,dl_dst=00:00:00:00:00:03,actions=output:3
sudo ovs-ofctl add-flow s21 dl_src=00:00:00:00:00:07,dl_dst=00:00:00:00:00:03,actions=output:4
sudo ovs-ofctl add-flow s12 dl_src=00:00:00:00:00:07,dl_dst=00:00:00:00:00:03,actions=output:1
sudo ovs-ofctl add-flow s23 dl_src=00:00:00:00:00:07,dl_dst=00:00:00:00:00:03,actions=output:1
sudo ovs-ofctl add-flow s34 dl_src=00:00:00:00:00:07,dl_dst=00:00:00:00:00:03,actions=output:1
# 4 -> 8
sudo ovs-ofctl add-flow s32 dl_src=00:00:00:00:00:04,dl_dst=00:00:00:00:00:08,actions=output:1
sudo ovs-ofctl add-flow s21 dl_src=00:00:00:00:00:04,dl_dst=00:00:00:00:00:08,actions=output:2
sudo ovs-ofctl add-flow s12 dl_src=00:00:00:00:00:04,dl_dst=00:00:00:00:00:08,actions=output:2
sudo ovs-ofctl add-flow s23 dl_src=00:00:00:00:00:04,dl_dst=00:00:00:00:00:08,actions=output:4
sudo ovs-ofctl add-flow s34 dl_src=00:00:00:00:00:04,dl_dst=00:00:00:00:00:08,actions=output:4
# 8 -> 4
sudo ovs-ofctl add-flow s32 dl_src=00:00:00:00:00:08,dl_dst=00:00:00:00:00:04,actions=output:4
sudo ovs-ofctl add-flow s21 dl_src=00:00:00:00:00:08,dl_dst=00:00:00:00:00:04,actions=output:4
sudo ovs-ofctl add-flow s12 dl_src=00:00:00:00:00:08,dl_dst=00:00:00:00:00:04,actions=output:1
sudo ovs-ofctl add-flow s23 dl_src=00:00:00:00:00:08,dl_dst=00:00:00:00:00:04,actions=output:1
sudo ovs-ofctl add-flow s34 dl_src=00:00:00:00:00:08,dl_dst=00:00:00:00:00:04,actions=output:1
# 5 -> 9
sudo ovs-ofctl add-flow s33 dl_src=00:00:00:00:00:05,dl_dst=00:00:00:00:00:09,actions=output:1
sudo ovs-ofctl add-flow s23 dl_src=00:00:00:00:00:05,dl_dst=00:00:00:00:00:09,actions=output:2
sudo ovs-ofctl add-flow s13 dl_src=00:00:00:00:00:05,dl_dst=00:00:00:00:00:09,actions=output:3
sudo ovs-ofctl add-flow s25 dl_src=00:00:00:00:00:05,dl_dst=00:00:00:00:00:09,actions=output:3
sudo ovs-ofctl add-flow s35 dl_src=00:00:00:00:00:05,dl_dst=00:00:00:00:00:09,actions=output:3
# 9 -> 5
sudo ovs-ofctl add-flow s33 dl_src=00:00:00:00:00:09,dl_dst=00:00:00:00:00:05,actions=output:3
sudo ovs-ofctl add-flow s23 dl_src=00:00:00:00:00:09,dl_dst=00:00:00:00:00:05,actions=output:3
sudo ovs-ofctl add-flow s13 dl_src=00:00:00:00:00:09,dl_dst=00:00:00:00:00:05,actions=output:2
sudo ovs-ofctl add-flow s25 dl_src=00:00:00:00:00:09,dl_dst=00:00:00:00:00:05,actions=output:1
sudo ovs-ofctl add-flow s35 dl_src=00:00:00:00:00:09,dl_dst=00:00:00:00:00:05,actions=output:1
# 6 -> 10
sudo ovs-ofctl add-flow s33 dl_src=00:00:00:00:00:06,dl_dst=00:00:00:00:00:0a,actions=output:1
sudo ovs-ofctl add-flow s23 dl_src=00:00:00:00:00:06,dl_dst=00:00:00:00:00:0a,actions=output:2
sudo ovs-ofctl add-flow s13 dl_src=00:00:00:00:00:06,dl_dst=00:00:00:00:00:0a,actions=output:3
sudo ovs-ofctl add-flow s25 dl_src=00:00:00:00:00:06,dl_dst=00:00:00:00:00:0a,actions=output:3
sudo ovs-ofctl add-flow s35 dl_src=00:00:00:00:00:06,dl_dst=00:00:00:00:00:0a,actions=output:4
# 10 -> 6
sudo ovs-ofctl add-flow s33 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:06,actions=output:4
sudo ovs-ofctl add-flow s23 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:06,actions=output:3
sudo ovs-ofctl add-flow s13 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:06,actions=output:2
sudo ovs-ofctl add-flow s25 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:06,actions=output:1
sudo ovs-ofctl add-flow s35 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:06,actions=output:1
# 7 -> 11
sudo ovs-ofctl add-flow s34 dl_src=00:00:00:00:00:07,dl_dst=00:00:00:00:00:0b,actions=output:2
sudo ovs-ofctl add-flow s24 dl_src=00:00:00:00:00:07,dl_dst=00:00:00:00:00:0b,actions=output:1
sudo ovs-ofctl add-flow s11 dl_src=00:00:00:00:00:07,dl_dst=00:00:00:00:00:0b,actions=output:3
sudo ovs-ofctl add-flow s26 dl_src=00:00:00:00:00:07,dl_dst=00:00:00:00:00:0b,actions=output:4
sudo ovs-ofctl add-flow s36 dl_src=00:00:00:00:00:07,dl_dst=00:00:00:00:00:0b,actions=output:3
# 11 -> 7
sudo ovs-ofctl add-flow s34 dl_src=00:00:00:00:00:0b,dl_dst=00:00:00:00:00:07,actions=output:3
sudo ovs-ofctl add-flow s24 dl_src=00:00:00:00:00:0b,dl_dst=00:00:00:00:00:07,actions=output:4
sudo ovs-ofctl add-flow s11 dl_src=00:00:00:00:00:0b,dl_dst=00:00:00:00:00:07,actions=output:2
sudo ovs-ofctl add-flow s26 dl_src=00:00:00:00:00:0b,dl_dst=00:00:00:00:00:07,actions=output:1
sudo ovs-ofctl add-flow s36 dl_src=00:00:00:00:00:0b,dl_dst=00:00:00:00:00:07,actions=output:2
# 8 -> 12
sudo ovs-ofctl add-flow s34 dl_src=00:00:00:00:00:08,dl_dst=00:00:00:00:00:0c,actions=output:2
sudo ovs-ofctl add-flow s24 dl_src=00:00:00:00:00:08,dl_dst=00:00:00:00:00:0c,actions=output:1
sudo ovs-ofctl add-flow s11 dl_src=00:00:00:00:00:08,dl_dst=00:00:00:00:00:0c,actions=output:3
sudo ovs-ofctl add-flow s26 dl_src=00:00:00:00:00:08,dl_dst=00:00:00:00:00:0c,actions=output:4
sudo ovs-ofctl add-flow s36 dl_src=00:00:00:00:00:08,dl_dst=00:00:00:00:00:0c,actions=output:4
# 12 -> 8
sudo ovs-ofctl add-flow s34 dl_src=00:00:00:00:00:0c,dl_dst=00:00:00:00:00:08,actions=output:4
sudo ovs-ofctl add-flow s24 dl_src=00:00:00:00:00:0c,dl_dst=00:00:00:00:00:08,actions=output:4
sudo ovs-ofctl add-flow s11 dl_src=00:00:00:00:00:0c,dl_dst=00:00:00:00:00:08,actions=output:2
sudo ovs-ofctl add-flow s26 dl_src=00:00:00:00:00:0c,dl_dst=00:00:00:00:00:08,actions=output:1
sudo ovs-ofctl add-flow s36 dl_src=00:00:00:00:00:0c,dl_dst=00:00:00:00:00:08,actions=output:2
# 9 -> 13
sudo ovs-ofctl add-flow s35 dl_src=00:00:00:00:00:09,dl_dst=00:00:00:00:00:0d,actions=output:1
sudo ovs-ofctl add-flow s25 dl_src=00:00:00:00:00:09,dl_dst=00:00:00:00:00:0d,actions=output:2
sudo ovs-ofctl add-flow s14 dl_src=00:00:00:00:00:09,dl_dst=00:00:00:00:00:0d,actions=output:4
sudo ovs-ofctl add-flow s27 dl_src=00:00:00:00:00:09,dl_dst=00:00:00:00:00:0d,actions=output:3
sudo ovs-ofctl add-flow s37 dl_src=00:00:00:00:00:09,dl_dst=00:00:00:00:00:0d,actions=output:3
# 13 -> 9
sudo ovs-ofctl add-flow s35 dl_src=00:00:00:00:00:0d,dl_dst=00:00:00:00:00:09,actions=output:3
sudo ovs-ofctl add-flow s25 dl_src=00:00:00:00:00:0d,dl_dst=00:00:00:00:00:09,actions=output:3
sudo ovs-ofctl add-flow s14 dl_src=00:00:00:00:00:0d,dl_dst=00:00:00:00:00:09,actions=output:3
sudo ovs-ofctl add-flow s27 dl_src=00:00:00:00:00:0d,dl_dst=00:00:00:00:00:09,actions=output:2
sudo ovs-ofctl add-flow s37 dl_src=00:00:00:00:00:0d,dl_dst=00:00:00:00:00:09,actions=output:1
# 10 -> 14
sudo ovs-ofctl add-flow s35 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:0e,actions=output:1
sudo ovs-ofctl add-flow s25 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:0e,actions=output:2
sudo ovs-ofctl add-flow s14 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:0e,actions=output:4
sudo ovs-ofctl add-flow s27 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:0e,actions=output:3
sudo ovs-ofctl add-flow s37 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:0e,actions=output:4
# 14 -> 10
sudo ovs-ofctl add-flow s35 dl_src=00:00:00:00:00:0e,dl_dst=00:00:00:00:00:0a,actions=output:4
sudo ovs-ofctl add-flow s25 dl_src=00:00:00:00:00:0e,dl_dst=00:00:00:00:00:0a,actions=output:3
sudo ovs-ofctl add-flow s14 dl_src=00:00:00:00:00:0e,dl_dst=00:00:00:00:00:0a,actions=output:3
sudo ovs-ofctl add-flow s27 dl_src=00:00:00:00:00:0e,dl_dst=00:00:00:00:00:0a,actions=output:2
sudo ovs-ofctl add-flow s37 dl_src=00:00:00:00:00:0e,dl_dst=00:00:00:00:00:0a,actions=output:1
# 11 -> 15
sudo ovs-ofctl add-flow s36 dl_src=00:00:00:00:00:0b,dl_dst=00:00:00:00:00:0f,actions=output:2
sudo ovs-ofctl add-flow s26 dl_src=00:00:00:00:00:0b,dl_dst=00:00:00:00:00:0f,actions=output:2
sudo ovs-ofctl add-flow s12 dl_src=00:00:00:00:00:0b,dl_dst=00:00:00:00:00:0f,actions=output:4
sudo ovs-ofctl add-flow s28 dl_src=00:00:00:00:00:0b,dl_dst=00:00:00:00:00:0f,actions=output:4
sudo ovs-ofctl add-flow s38 dl_src=00:00:00:00:00:0b,dl_dst=00:00:00:00:00:0f,actions=output:3
# 15 -> 11
sudo ovs-ofctl add-flow s36 dl_src=00:00:00:00:00:0f,dl_dst=00:00:00:00:00:0b,actions=output:3
sudo ovs-ofctl add-flow s26 dl_src=00:00:00:00:00:0f,dl_dst=00:00:00:00:00:0b,actions=output:4
sudo ovs-ofctl add-flow s12 dl_src=00:00:00:00:00:0f,dl_dst=00:00:00:00:00:0b,actions=output:3
sudo ovs-ofctl add-flow s28 dl_src=00:00:00:00:00:0f,dl_dst=00:00:00:00:00:0b,actions=output:1
sudo ovs-ofctl add-flow s38 dl_src=00:00:00:00:00:0f,dl_dst=00:00:00:00:00:0b,actions=output:2
# 12 -> 16
sudo ovs-ofctl add-flow s36 dl_src=00:00:00:00:00:0c,dl_dst=00:00:00:00:00:10,actions=output:2
sudo ovs-ofctl add-flow s26 dl_src=00:00:00:00:00:0c,dl_dst=00:00:00:00:00:10,actions=output:2
sudo ovs-ofctl add-flow s12 dl_src=00:00:00:00:00:0c,dl_dst=00:00:00:00:00:10,actions=output:4
sudo ovs-ofctl add-flow s28 dl_src=00:00:00:00:00:0c,dl_dst=00:00:00:00:00:10,actions=output:4
sudo ovs-ofctl add-flow s38 dl_src=00:00:00:00:00:0c,dl_dst=00:00:00:00:00:10,actions=output:4
# 16 -> 12
sudo ovs-ofctl add-flow s36 dl_src=00:00:00:00:00:10,dl_dst=00:00:00:00:00:0c,actions=output:4
sudo ovs-ofctl add-flow s26 dl_src=00:00:00:00:00:10,dl_dst=00:00:00:00:00:0c,actions=output:4
sudo ovs-ofctl add-flow s12 dl_src=00:00:00:00:00:10,dl_dst=00:00:00:00:00:0c,actions=output:3
sudo ovs-ofctl add-flow s28 dl_src=00:00:00:00:00:10,dl_dst=00:00:00:00:00:0c,actions=output:1
sudo ovs-ofctl add-flow s38 dl_src=00:00:00:00:00:10,dl_dst=00:00:00:00:00:0c,actions=output:2
