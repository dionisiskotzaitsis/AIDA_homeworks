sudo ovs-ofctl add-flow s31 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:0a,nw_ttl=64,actions=mod_dl_src:13:34:00:00:00:00,dec_ttl,output:2
sudo ovs-ofctl add-flow s35 priority=10,dl_type=0x0800,dl_dst=00:00:00:00:00:01,nw_ttl=64,actions=mod_dl_src:11:33:00:00:00:00,dec_ttl,output:1




sudo ovs-ofctl add-flow s22 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s22 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s22 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s22 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s22 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s22 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]








sudo ovs-ofctl add-flow s13 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s13 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s13 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s13 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s13 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s13 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]








sudo ovs-ofctl add-flow s25 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s25 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s25 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s25 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s25 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s25 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]







sudo ovs-ofctl add-flow s35 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s35 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s35 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s35 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s35 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s35 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]







sudo ovs-ofctl add-flow s31 priority=1,dl_type=0x0800,nw_ttl=63,actions=dec_ttl,output:NXM_OF_ETH_SRC[44..47]
sudo ovs-ofctl add-flow s31 priority=1,dl_type=0x0800,nw_ttl=62,actions=dec_ttl,output:NXM_OF_ETH_SRC[40..43]
sudo ovs-ofctl add-flow s31 priority=1,dl_type=0x0800,nw_ttl=61,actions=dec_ttl,output:NXM_OF_ETH_SRC[36..39]
sudo ovs-ofctl add-flow s31 priority=1,dl_type=0x0800,nw_ttl=60,actions=dec_ttl,output:NXM_OF_ETH_SRC[32..35]
sudo ovs-ofctl add-flow s31 priority=1,dl_type=0x0800,nw_ttl=59,actions=dec_ttl,output:NXM_OF_ETH_SRC[28..31]
sudo ovs-ofctl add-flow s31 priority=1,dl_type=0x0800,nw_ttl=58,actions=dec_ttl,output:NXM_OF_ETH_SRC[24..27]





