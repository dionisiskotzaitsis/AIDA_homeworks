# 1 -> 10
sudo ovs-ofctl add-flow s31 dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:0a,actions=output:2
sudo ovs-ofctl add-flow s22 dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:0a,actions=output:1
sudo ovs-ofctl add-flow s13 dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:0a,actions=output:3
sudo ovs-ofctl add-flow s25 dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:0a,actions=output:3
sudo ovs-ofctl add-flow s35 dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:0a,actions=output:4
# 10 -> 1
sudo ovs-ofctl add-flow s35 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:01,actions=output:1
sudo ovs-ofctl add-flow s25 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:01,actions=output:1
sudo ovs-ofctl add-flow s13 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:01,actions=output:1
sudo ovs-ofctl add-flow s22 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:01,actions=output:3
sudo ovs-ofctl add-flow s31 dl_src=00:00:00:00:00:0a,dl_dst=00:00:00:00:00:01,actions=output:3